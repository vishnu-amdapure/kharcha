# Kharcha — Personal Finance Tracker

Kharcha is a personal finance web app for tracking income, expenses, budgets, lending, repayments, recurring transactions, and monthly reports.

## Created by

**Vishnu Shivaji Amdapure**

## Project structure

- `frontend/` — React + Vite interface
- `backend/` — Laravel API and database migrations
- `Kharcha API.postman_collection.json` — API request collection
- `DEPLOYMENT_GUIDE_MR.md` — deployment preparation guide in Marathi

## Website and app

- `/` is the public Kharcha homepage with search-friendly content and Vishnu Shivaji Amdapure's creator credit.
- `/app/` is the React finance app for sign-in and account creation.
- `/api/` is the Laravel API.

The Dockerfile builds React and Laravel into one web service for a simple demo deployment. See `DEPLOYMENT_GUIDE_MR.md` for free-hosting limits and setup.

## Run locally

Run the Laravel backend and React frontend in separate terminals. Open the Vite URL for the homepage and add `/app/` to open the finance app. Follow `LARAVEL_GUIDE_MR.md` for local API and database instructions.

## Data safety

Do not upload `.env` files, database files, passwords, API tokens, or real financial data to a source repository. The public homepage can be indexed by search engines; the account app is marked `noindex`.
