// Mock data is disabled. All requests go to the Laravel API.
const API_URL = import.meta.env.VITE_API_URL || "http://127.0.0.1:8000/api";

async function request(path, options = {}) {
  const token = localStorage.getItem("kharcha_token");
  const isFormData = options.body instanceof FormData;

  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      Accept: "application/json",
      ...(!isFormData ? { "Content-Type": "application/json" } : {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const validationMessage = Object.values(data.errors || {}).flat()[0];
    throw new Error(
      validationMessage || data.message || "Something went wrong.",
    );
  }

  return data;
}

function transactionPayload(item) {
  return {
    description: item.description || item.name,
    category:
      typeof item.category === "string"
        ? item.category
        : item.category?.name || "Other",
    amount: Number(item.amount),
    type: item.type || item.kind,
    date: item.date,
  };
}

export const api = {
  register: (payload) =>
    request("/auth/register", {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  login: (payload) =>
    request("/auth/login", {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  logout: () => request("/auth/logout", { method: "POST" }),

  updateProfile: (payload) =>
    request("/profile", {
      method: "PUT",
      body: JSON.stringify(payload),
    }),

  updateProfilePhoto: (photo) => {
    const body = new FormData();
    body.append("photo", photo);
    return request("/profile/photo", { method: "POST", body });
  },

  deleteProfilePhoto: () => request("/profile/photo", { method: "DELETE" }),

  updatePassword: (payload) =>
    request("/profile/password", {
      method: "PATCH",
      body: JSON.stringify(payload),
    }),

  requestPasswordReset: (payload) =>
    request("/auth/forgot-password", {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  resetPassword: (payload) =>
    request("/auth/reset-password", {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  getTransactions: (filters = {}) => {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== "") {
        params.set(key, value);
      }
    });
    const query = params.toString();
    return request(`/transactions${query ? `?${query}` : ""}`);
  },

  createTransaction: (payload) =>
    request("/transactions", {
      method: "POST",
      body: JSON.stringify(transactionPayload(payload)),
    }),

  updateTransaction: (id, payload) =>
    request(`/transactions/${id}`, {
      method: "PUT",
      body: JSON.stringify(transactionPayload(payload)),
    }),

  deleteTransaction: (id) =>
    request(`/transactions/${id}`, {
      method: "DELETE",
    }),

  getRecurringTransactions: () => request("/recurring-transactions"),

  createRecurringTransaction: (payload) =>
    request("/recurring-transactions", {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  updateRecurringTransaction: (id, payload) =>
    request(`/recurring-transactions/${id}`, {
      method: "PATCH",
      body: JSON.stringify(payload),
    }),

  deleteRecurringTransaction: (id) =>
    request(`/recurring-transactions/${id}`, { method: "DELETE" }),

  processDueRecurringTransactions: () =>
    request("/recurring-transactions/process-due", { method: "POST" }),

  getCategories: () => request("/categories"),

  createCategory: (name) =>
    request("/categories", {
      method: "POST",
      body: JSON.stringify({ name }),
    }),

  updateCategory: (id, name) =>
    request(`/categories/${id}`, {
      method: "PUT",
      body: JSON.stringify({ name }),
    }),

  deleteCategory: (id) =>
    request(`/categories/${id}`, {
      method: "DELETE",
    }),

  getUdhars: () => request("/udhars"),

  createUdhar: (payload) =>
    request("/udhars", {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  updateUdhar: (id, payload) =>
    request(`/udhars/${id}`, {
      method: "PUT",
      body: JSON.stringify(payload),
    }),

  deleteUdhar: (id) =>
    request(`/udhars/${id}`, {
      method: "DELETE",
    }),

  addUdharPayment: (id, payload) =>
    request(`/udhars/${id}/payments`, {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  getSummary: (period = "this_month") =>
    request(`/dashboard/summary?period=${encodeURIComponent(period)}`),

  getMonthlyReport: (month) =>
    request(`/reports/monthly?month=${encodeURIComponent(month)}`),

  getBackup: () => request("/backup"),

  restoreBackup: (backup) =>
    request("/backup/restore", {
      method: "POST",
      body: JSON.stringify(backup),
    }),

  getBudgets: (month) =>
    request(`/budgets${month ? `?month=${encodeURIComponent(month)}` : ""}`),

  createBudget: (payload) =>
    request("/budgets", {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  updateBudget: (id, payload) =>
    request(`/budgets/${id}`, {
      method: "PUT",
      body: JSON.stringify(payload),
    }),

  deleteBudget: (id) =>
    request(`/budgets/${id}`, {
      method: "DELETE",
    }),
};
