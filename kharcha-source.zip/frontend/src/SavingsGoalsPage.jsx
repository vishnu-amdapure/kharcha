import { useEffect, useMemo, useState } from "react";
import { api } from "./api";

const blankGoal = { name: "", target_amount: "", saved_amount: "", target_date: "" };
const formatMoney = (amount) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(Number(amount) || 0);

function SavingsGoalsPage({ toast }) {
  const [goals, setGoals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [editingGoal, setEditingGoal] = useState(null);
  const [form, setForm] = useState(blankGoal);

  const loadGoals = async () => {
    setLoading(true);
    setError("");
    try {
      const response = await api.getSavingsGoals();
      setGoals(Array.isArray(response) ? response : response?.data || []);
    } catch (loadError) {
      setError(loadError.message || "Could not load your savings goals.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadGoals();
  }, []);

  const totals = useMemo(
    () =>
      goals.reduce(
        (result, goal) => ({
          target: result.target + Number(goal.target_amount || 0),
          saved: result.saved + Number(goal.saved_amount || 0),
        }),
        { target: 0, saved: 0 },
      ),
    [goals],
  );

  const startEdit = (goal) => {
    setEditingGoal(goal);
    setForm({
      name: goal.name,
      target_amount: String(goal.target_amount),
      saved_amount: String(goal.saved_amount),
      target_date: goal.target_date || "",
    });
    document.querySelector(".goal-form-panel")?.scrollIntoView({ behavior: "smooth", block: "center" });
  };

  const resetForm = () => {
    setEditingGoal(null);
    setForm(blankGoal);
  };

  const saveGoal = async (event) => {
    event.preventDefault();
    setSaving(true);
    const payload = {
      name: form.name.trim(),
      target_amount: Number(form.target_amount),
      saved_amount: Number(form.saved_amount || 0),
      target_date: form.target_date || null,
    };
    try {
      if (editingGoal) {
        await api.updateSavingsGoal(editingGoal.id, payload);
        toast("Savings goal updated");
      } else {
        await api.createSavingsGoal(payload);
        toast("Savings goal added");
      }
      resetForm();
      await loadGoals();
    } catch (saveError) {
      toast(saveError.message || "Could not save this goal.");
    } finally {
      setSaving(false);
    }
  };

  const deleteGoal = async (goal) => {
    if (!window.confirm(`Delete the “${goal.name}” savings goal?`)) return;
    try {
      await api.deleteSavingsGoal(goal.id);
      setGoals((current) => current.filter((item) => item.id !== goal.id));
      if (editingGoal?.id === goal.id) resetForm();
      toast("Savings goal deleted");
    } catch (deleteError) {
      toast(deleteError.message || "Could not delete this goal.");
    }
  };

  const dateLabel = (date) =>
    date
      ? new Date(`${date}T12:00:00`).toLocaleDateString("en-IN", {
          day: "numeric",
          month: "short",
          year: "numeric",
        })
      : "No target date";

  return (
    <>
      <div className="page-heading goals-heading">
        <div>
          <div className="eyebrow"><span className="live-dot" /> SAVE WITH A PLAN</div>
          <h1>Savings goals</h1>
          <p>Choose what you’re saving for and keep track of your progress.</p>
        </div>
      </div>

      <section className="summary-grid goals-summary-grid" aria-label="Savings totals">
        <div className="summary-card">
          <span className="card-label">TOTAL SAVED TOWARDS GOALS</span>
          <div className="metric-value">{formatMoney(totals.saved)}</div>
          <div className="metric-caption">Across {goals.length} {goals.length === 1 ? "goal" : "goals"}</div>
        </div>
        <div className="summary-card">
          <span className="card-label">TOTAL GOAL AMOUNT</span>
          <div className="metric-value">{formatMoney(totals.target)}</div>
          <div className="metric-caption">Your combined savings targets</div>
        </div>
      </section>

      {error && (
        <div className="api-alert" role="alert">
          <span>!</span><div><b>Could not load savings goals</b><small>{error}</small></div>
          <button onClick={loadGoals}>Try again</button>
        </div>
      )}

      <div className="goals-layout">
        <section className="goals-list" aria-label="Your savings goals">
          {loading ? (
            <div className="panel inline-state">Loading your savings goals…</div>
          ) : goals.length ? (
            goals.map((goal) => {
              const percentage = Math.min(Number(goal.percentage) || 0, 100);
              const complete = percentage >= 100;
              return (
                <article className="panel savings-goal-card" key={goal.id}>
                  <div className="goal-card-top">
                    <div className="goal-symbol" aria-hidden="true">{complete ? "✓" : "◎"}</div>
                    <div className="goal-card-title"><h2>{goal.name}</h2><p>{complete ? "Goal reached" : dateLabel(goal.target_date)}</p></div>
                    <div className="goal-card-actions">
                      <button className="secondary-button" onClick={() => startEdit(goal)}>Edit</button>
                      <button className="secondary-button danger-button" onClick={() => deleteGoal(goal)}>Delete</button>
                    </div>
                  </div>
                  <div className="goal-progress-labels">
                    <span>{formatMoney(goal.saved_amount)} saved</span><b>{Math.round(percentage)}%</b>
                  </div>
                  <div className="goal-progress-track" role="progressbar" aria-label={`${goal.name} progress`} aria-valuenow={Math.round(percentage)} aria-valuemin="0" aria-valuemax="100">
                    <span style={{ width: `${percentage}%` }} />
                  </div>
                  <div className="goal-amount-row">
                    <span>{complete ? "You reached your target" : `${formatMoney(goal.remaining_amount)} left`}</span>
                    <span>of {formatMoney(goal.target_amount)}</span>
                  </div>
                </article>
              );
            })
          ) : (
            <div className="panel empty-state goals-empty-state">
              <span>◎</span><b>Your first goal starts here</b>
              <p>Add a goal such as an emergency fund, a new phone, or a trip. You can update the saved amount whenever you add to it.</p>
            </div>
          )}
        </section>

        <form className="panel goal-form-panel" onSubmit={saveGoal}>
          <div className="goal-form-heading">
            <div className="eyebrow"><span className="live-dot" /> MAKE IT HAPPEN</div>
            <h2>{editingGoal ? "Edit your goal" : "Add a savings goal"}</h2>
            <p>Enter the amount you want to save and your current progress.</p>
          </div>
          <label className="goal-field">Goal name
            <input required maxLength="100" placeholder="For example, emergency fund" value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} />
          </label>
          <div className="goal-form-row">
            <label className="goal-field">Target amount (₹)
              <input required type="number" min="0.01" step="0.01" placeholder="50000" value={form.target_amount} onChange={(event) => setForm({ ...form, target_amount: event.target.value })} />
            </label>
            <label className="goal-field">Already saved (₹)
              <input type="number" min="0" step="0.01" placeholder="0" value={form.saved_amount} onChange={(event) => setForm({ ...form, saved_amount: event.target.value })} />
            </label>
          </div>
          <label className="goal-field">Target date <span className="goal-optional">(optional)</span>
            <input type="date" value={form.target_date} onChange={(event) => setForm({ ...form, target_date: event.target.value })} />
          </label>
          {form.target_amount && Number(form.saved_amount || 0) > Number(form.target_amount) && (
            <p className="goal-validation" role="alert">Saved amount can’t be higher than the target amount.</p>
          )}
          <div className="goal-form-actions">
            {editingGoal && <button type="button" className="secondary-button" onClick={resetForm}>Cancel</button>}
            <button className="primary-button" type="submit" disabled={saving || !form.target_amount || Number(form.saved_amount || 0) > Number(form.target_amount)}>
              <span>{editingGoal ? "✓" : "＋"}</span>{saving ? "Saving…" : editingGoal ? "Save changes" : "Add goal"}
            </button>
          </div>
          <p className="goal-privacy-note">Goal progress is saved to your account and included in your data backup. It does not add transactions.</p>
        </form>
      </div>
    </>
  );
}

export default SavingsGoalsPage;
