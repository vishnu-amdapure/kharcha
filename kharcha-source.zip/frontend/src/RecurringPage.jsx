import { useEffect, useState } from "react";
import { api } from "./api";

const money = (amount) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(Number(amount || 0));

const today = () => new Date().toISOString().slice(0, 10);

export default function RecurringPage({ categories, toast, onTransactionsChanged }) {
  const [schedules, setSchedules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    description: "",
    category: categories[0]?.name || "Other",
    amount: "",
    type: "expense",
    frequency: "monthly",
    start_date: today(),
    end_date: "",
  });

  const loadSchedules = async () => {
    setLoading(true);
    setError("");
    try {
      const response = await api.getRecurringTransactions();
      setSchedules(Array.isArray(response) ? response : response?.data || []);
    } catch (loadError) {
      setError(loadError.message || "Could not load repeating transactions.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSchedules();
  }, []);

  useEffect(() => {
    if (categories.length && (!form.category || form.category === "Other")) {
      setForm((current) => ({ ...current, category: categories[0].name }));
    }
  }, [categories]);

  const saveSchedule = async (event) => {
    event.preventDefault();
    setSaving(true);
    setError("");
    try {
      await api.createRecurringTransaction({
        ...form,
        amount: Number(form.amount),
        end_date: form.end_date || null,
      });
      await loadSchedules();
      setForm((current) => ({ ...current, description: "", amount: "" }));
      let result;
      try {
        result = await api.processDueRecurringTransactions();
      } catch {
        toast("Schedule saved. Due entries will be added when the app opens.");
        return;
      }
      if (result.created_count > 0) {
        await onTransactionsChanged();
        toast(`${result.created_count} repeating transaction added.`);
      } else {
        toast("Repeating transaction saved.");
      }
    } catch (saveError) {
      setError(saveError.message || "Could not save the repeating transaction.");
    } finally {
      setSaving(false);
    }
  };

  const toggleSchedule = async (schedule) => {
    try {
      const updated = await api.updateRecurringTransaction(schedule.id, {
        active: !schedule.active,
      });
      setSchedules((current) =>
        current.map((item) => (item.id === schedule.id ? updated : item)),
      );
      toast(updated.active ? "Repeating transaction resumed." : "Repeating transaction paused.");
    } catch (updateError) {
      setError(updateError.message || "Could not update this schedule.");
    }
  };

  const removeSchedule = async (schedule) => {
    if (!window.confirm(`Delete the repeating transaction “${schedule.description}”?`)) {
      return;
    }
    try {
      await api.deleteRecurringTransaction(schedule.id);
      setSchedules((current) => current.filter((item) => item.id !== schedule.id));
      toast("Repeating transaction deleted.");
    } catch (deleteError) {
      setError(deleteError.message || "Could not delete this schedule.");
    }
  };

  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">
            <span className="live-dot" /> AUTOMATE YOUR MONEY MOVES
          </div>
          <h1>Recurring transactions</h1>
          <p>Set regular income or expenses once. Kharcha adds due entries when you open the app.</p>
        </div>
      </div>

      {error && (
        <div className="api-alert recurring-alert">
          <span>!</span>
          <div>
            <b>Something needs attention</b>
            <small>{error}</small>
          </div>
          <button onClick={loadSchedules}>Retry</button>
        </div>
      )}

      <div className="recurring-layout">
        <form className="panel recurring-form" onSubmit={saveSchedule}>
          <div className="panel-heading">
            <div>
              <h2>Add a repeating transaction</h2>
              <p>For example, monthly rent or weekly groceries.</p>
            </div>
          </div>

          <div className="type-switch">
            <button
              type="button"
              className={form.type === "expense" ? "active" : ""}
              onClick={() => setForm((current) => ({ ...current, type: "expense" }))}
            >
              ↗ Expense
            </button>
            <button
              type="button"
              className={form.type === "income" ? "active income-active" : ""}
              onClick={() => setForm((current) => ({ ...current, type: "income" }))}
            >
              ↙ Income
            </button>
          </div>

          <label>
            Description
            <input
              required
              maxLength="255"
              placeholder="e.g. House rent"
              value={form.description}
              onChange={(event) => setForm((current) => ({ ...current, description: event.target.value }))}
            />
          </label>

          <div className="form-row">
            <label>
              Amount
              <input
                required
                min="0.01"
                step="0.01"
                type="number"
                placeholder="₹ 0"
                value={form.amount}
                onChange={(event) => setForm((current) => ({ ...current, amount: event.target.value }))}
              />
            </label>
            <label>
              Category
              <select
                value={form.category}
                onChange={(event) => setForm((current) => ({ ...current, category: event.target.value }))}
              >
                {categories.length ? categories.map((category) => (
                  <option key={category.id} value={category.name}>{category.name}</option>
                )) : <option value="Other">Other</option>}
              </select>
            </label>
          </div>

          <div className="form-row">
            <label>
              Repeat
              <select
                value={form.frequency}
                onChange={(event) => setForm((current) => ({ ...current, frequency: event.target.value }))}
              >
                <option value="monthly">Every month</option>
                <option value="weekly">Every week</option>
              </select>
            </label>
            <label>
              First date
              <input
                required
                type="date"
                value={form.start_date}
                onChange={(event) => setForm((current) => ({ ...current, start_date: event.target.value }))}
              />
            </label>
          </div>

          <label>
            End date <span className="field-optional">Optional</span>
            <input
              type="date"
              min={form.start_date}
              value={form.end_date}
              onChange={(event) => setForm((current) => ({ ...current, end_date: event.target.value }))}
            />
          </label>

          <button className="primary-button recurring-submit" type="submit" disabled={saving}>
            {saving ? "Saving…" : "Save repeating transaction"} <span>→</span>
          </button>
        </form>

        <section className="recurring-list">
          <div className="panel-heading recurring-list-heading">
            <div>
              <h2>Your schedules</h2>
              <p>{schedules.length} repeating {schedules.length === 1 ? "transaction" : "transactions"}</p>
            </div>
          </div>
          {loading ? (
            <div className="panel inline-state">Loading your schedules…</div>
          ) : schedules.length ? (
            <div className="recurring-cards">
              {schedules.map((schedule) => (
                <article className={`panel recurring-card ${schedule.active ? "" : "is-paused"}`} key={schedule.id}>
                  <div className="recurring-card-top">
                    <span className={`recurring-icon ${schedule.type}`}>{schedule.type === "income" ? "↙" : "↗"}</span>
                    <span className={`schedule-status ${schedule.active ? "active" : "paused"}`}>
                      {schedule.active ? "Active" : "Paused"}
                    </span>
                  </div>
                  <div className="recurring-amount">{money(schedule.amount)}</div>
                  <h3>{schedule.description}</h3>
                  <p>{schedule.category} · {schedule.frequency === "weekly" ? "Every week" : "Every month"}</p>
                  <div className="schedule-next">
                    {schedule.active ? `Next date: ${schedule.next_due_date}` : "This schedule is paused"}
                  </div>
                  <div className="recurring-actions">
                    <button className="secondary-button" onClick={() => toggleSchedule(schedule)}>
                      {schedule.active ? "Pause" : "Resume"}
                    </button>
                    <button className="secondary-button danger-button" onClick={() => removeSchedule(schedule)}>
                      Delete
                    </button>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div className="panel empty-state recurring-empty">
              <span>↻</span>
              <b>No repeating transactions yet</b>
              <p>Add salary, rent, subscriptions, or other regular money moves here.</p>
            </div>
          )}
        </section>
      </div>
    </>
  );
}
