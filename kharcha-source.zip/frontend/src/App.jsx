import { useEffect, useMemo, useRef, useState } from "react";
import { api } from "./api";
import UdharPage from "./UdharPage";
import BudgetsPage from "./BudgetsPage";
import AuthPage from "./AuthPage";
import RecurringPage from "./RecurringPage";
import MonthlyReportPage from "./MonthlyReportPage";
import DueReminders from "./DueReminders";
import SavingsGoalsPage from "./SavingsGoalsPage";

const nav = [
  { id: "Overview", icon: "⌂" },
  { id: "Transactions", icon: "⇄" },
  { id: "Recurring", icon: "↻" },
  { id: "Reports", icon: "▤" },
  { id: "Categories", icon: "▦" },
  { id: "Budgets", icon: "◷" },
  { id: "Goals", icon: "◎" },
  { id: "Lending", icon: "↔" },
];
const money = (n) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(n);
const prettyDate = (s) =>
  new Date(`${s}T12:00:00`).toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
  });

function Icon({ children }) {
  return (
    <span className="icon" aria-hidden="true">
      {children}
    </span>
  );
}

function UserAvatar({ user, className = "" }) {
  return (
    <span className={`avatar ${className}`} aria-label={`${user.name} profile photo`}>
      {user.profile_photo ? (
        <img src={user.profile_photo} alt="" />
      ) : (
        user.name.slice(0, 1).toUpperCase()
      )}
    </span>
  );
}

function FinanceApp({ user, onSignOut, onUserUpdated }) {
  const [page, setPage] = useState("Overview");
  const [mobileMoreOpen, setMobileMoreOpen] = useState(false);
  const [transactions, setTransactions] = useState([]);
  const [serverTransactions, setServerTransactions] = useState(null);
  const [filterLoading, setFilterLoading] = useState(false);
  const [filterError, setFilterError] = useState("");
  const [filterReload, setFilterReload] = useState(0);
  const [transactionPage, setTransactionPage] = useState(1);
  const [transactionPagination, setTransactionPagination] = useState(null);

  const [categories, setCategories] = useState([]);
  const [categoryLoading, setCategoryLoading] = useState(true);
  const [categoryError, setCategoryError] = useState("");
  const [categoryModal, setCategoryModal] = useState(false);
  const [categoryName, setCategoryName] = useState("");
  const [editingCategory, setEditingCategory] = useState(null);

  const [apiError, setApiError] = useState("");
  const [summary, setSummary] = useState(null);
  const [overviewBudgets, setOverviewBudgets] = useState([]);
  const [overviewBudgetLoading, setOverviewBudgetLoading] = useState(true);
  const [overviewBudgetError, setOverviewBudgetError] = useState("");
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("All");
  const [dateFilter, setDateFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [sortOrder, setSortOrder] = useState("newest");
  const [categoryPeriod, setCategoryPeriod] = useState("this_month");
  const [modal, setModal] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState(null);
  const [notice, setNotice] = useState("");
  const [profileEditing, setProfileEditing] = useState(false);
  const [profileName, setProfileName] = useState(user.name);
  const [profileEmail, setProfileEmail] = useState(user.email);
  const [profileSaving, setProfileSaving] = useState(false);
  const [profilePhotoSaving, setProfilePhotoSaving] = useState(false);
  const [backupDownloading, setBackupDownloading] = useState(false);
  const [backupRestoring, setBackupRestoring] = useState(false);
  const backupFileInput = useRef(null);
  const profilePhotoInput = useRef(null);
  const [profileError, setProfileError] = useState("");
  const [passwordEditing, setPasswordEditing] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newPasswordConfirmation, setNewPasswordConfirmation] = useState("");
  const [passwordSaving, setPasswordSaving] = useState(false);
  const [passwordError, setPasswordError] = useState("");
  const [showProfilePasswords, setShowProfilePasswords] = useState(false);
  const [form, setForm] = useState({
    name: "",
    category: "Other",
    amount: "",
    kind: "expense",
    date: new Date().toISOString().slice(0, 10),
  });
  const expenses = transactions
    .filter((t) => t.kind === "expense")
    .reduce((a, t) => a + Number(t.amount), 0);
  const income = transactions
    .filter((t) => t.kind === "income")
    .reduce((a, t) => a + Number(t.amount), 0);
  const categorySpending = useMemo(() => {
    const now = new Date();
    const monthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
    const totals = transactions
      .filter(
        (transaction) =>
          transaction.kind === "expense" &&
          String(transaction.date || "").startsWith(monthKey),
      )
      .reduce((groups, transaction) => {
        const name = transaction.category || "Other";
        groups[name] = (groups[name] || 0) + Number(transaction.amount || 0);
        return groups;
      }, {});

    return Object.entries(totals)
      .map(([name, amount]) => ({ name, amount }))
      .sort((a, b) => b.amount - a.amount);
  }, [transactions]);
  const displayedCategorySpending =
    summary?.category_spending || categorySpending;
  const categorySpendingTotal = displayedCategorySpending.reduce(
    (total, category) => total + category.amount,
    0,
  );
  const categoryColors = [
    "#2f7253",
    "#74a987",
    "#a5c9ac",
    "#e1ad88",
    "#91a8a0",
  ];
  const cashFlow = useMemo(() => {
    const currentMonth = new Date();
    const months = Array.from({ length: 6 }, (_, index) => {
      const date = new Date(
        currentMonth.getFullYear(),
        currentMonth.getMonth() - 5 + index,
        1,
      );
      const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
      const monthTransactions = transactions.filter((transaction) =>
        String(transaction.date || "").startsWith(key),
      );

      return {
        key,
        label: date.toLocaleDateString("en-IN", { month: "short" }),
        income: monthTransactions
          .filter((transaction) => transaction.kind === "income")
          .reduce(
            (total, transaction) => total + Number(transaction.amount || 0),
            0,
          ),
        expenses: monthTransactions
          .filter((transaction) => transaction.kind === "expense")
          .reduce(
            (total, transaction) => total + Number(transaction.amount || 0),
            0,
          ),
      };
    });
    const maxAmount = Math.max(
      1,
      ...months.flatMap((month) => [month.income, month.expenses]),
    );

    return { months, maxAmount };
  }, [transactions]);
  const displayedCashFlow = summary?.cash_flow
    ? {
        months: summary.cash_flow,
        maxAmount: Math.max(
          1,
          ...summary.cash_flow.flatMap((month) => [
            Number(month.income || 0),
            Number(month.expenses || 0),
          ]),
        ),
      }
    : cashFlow;
  const displayedIncome = Number(summary?.income ?? income);
  const displayedExpenses = Number(summary?.expenses ?? expenses);
  const displayedBalance = Number(
    summary?.balance ?? displayedIncome - displayedExpenses,
  );
  const loadTransactions = async () => {
    setLoading(true);
    setApiError("");
    try {
      const response = await api.getTransactions();
      const rows = Array.isArray(response)
        ? response
        : Array.isArray(response?.data)
          ? response.data
          : Array.isArray(response?.data?.data)
            ? response.data.data
            : [];
      setTransactions(
        rows.map((t) => ({
          ...t,
          name: t.name || t.description || "Transaction",
          category: t.category?.name || t.category || "Other",
          kind: t.kind || t.type || "expense",
          icon: t.icon || (t.type === "income" ? "↗" : "◈"),
          color: t.color || "mint",
        })),
      );
    } catch (error) {
      setApiError(error.message || "Could not connect to the Laravel API.");
    } finally {
      setLoading(false);
    }
  };

  const loadSummary = async (period = categoryPeriod) => {
    try {
      const response = await api.getSummary(period);
      setSummary(response);
    } catch {
      setSummary(null);
    }
  };

  const loadOverviewBudgets = async () => {
    setOverviewBudgetLoading(true);
    setOverviewBudgetError("");
    try {
      const response = await api.getBudgets();
      const rows = Array.isArray(response) ? response : response?.data || [];
      setOverviewBudgets(rows);
      return rows;
    } catch (error) {
      setOverviewBudgetError(error.message || "Could not load budgets.");
      return [];
    } finally {
      setOverviewBudgetLoading(false);
    }
  };

  useEffect(() => {
    const initializeApp = async () => {
      let createdCount = 0;
      try {
        const result = await api.processDueRecurringTransactions();
        createdCount = Number(result.created_count || 0);
      } catch {
        // Keep the dashboard available if the recurring API is temporarily unavailable.
      }

      await Promise.all([loadTransactions(), loadCategories()]);
      if (createdCount > 0) {
        await Promise.all([loadSummary(), loadOverviewBudgets()]);
        toast(`${createdCount} repeating transaction${createdCount === 1 ? "" : "s"} added.`);
      }
    };

    initializeApp();
  }, []);
  useEffect(() => {
    loadOverviewBudgets();
  }, [page]);
  useEffect(() => {
    loadSummary(categoryPeriod);
  }, [categoryPeriod]);
  useEffect(() => {
    if (page !== "Transactions") {
      setServerTransactions(null);
      setTransactionPagination(null);
      setFilterLoading(false);
      return;
    }

    let cancelled = false;
    const now = new Date();
    const formatDate = (date) =>
      `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
    const filters = {
      type: filter === "All" ? "" : filter.toLowerCase(),
      category: categoryFilter === "all" ? "" : categoryFilter,
      search: query.trim(),
      sort: sortOrder,
      per_page: 10,
      page: transactionPage,
    };

    if (dateFilter === "this_month") {
      filters.from = formatDate(new Date(now.getFullYear(), now.getMonth(), 1));
      filters.to = formatDate(
        new Date(now.getFullYear(), now.getMonth() + 1, 0),
      );
    } else if (dateFilter === "last_month") {
      filters.from = formatDate(
        new Date(now.getFullYear(), now.getMonth() - 1, 1),
      );
      filters.to = formatDate(new Date(now.getFullYear(), now.getMonth(), 0));
    } else if (dateFilter === "this_year") {
      filters.from = `${now.getFullYear()}-01-01`;
      filters.to = `${now.getFullYear()}-12-31`;
    }

    const timer = setTimeout(async () => {
      setFilterLoading(true);
      setFilterError("");
      try {
        const response = await api.getTransactions(filters);
        const rows = Array.isArray(response)
          ? response
          : Array.isArray(response?.data)
            ? response.data
            : [];
        if (!cancelled) {
          setServerTransactions(
            rows.map((transaction) => ({
              ...transaction,
              name:
                transaction.name || transaction.description || "Transaction",
              category:
                transaction.category?.name || transaction.category || "Other",
              kind: transaction.kind || transaction.type || "expense",
              icon:
                transaction.icon ||
                (transaction.type === "income" ? "↗" : "◈"),
              color: transaction.color || "mint",
            })),
          );
          setTransactionPagination(
            response && !Array.isArray(response)
              ? {
                  currentPage: Number(response.current_page || transactionPage),
                  lastPage: Number(response.last_page || 1),
                  total: Number(response.total || 0),
                  perPage: Number(response.per_page || 10),
                }
              : null,
          );
        }
      } catch (error) {
        if (!cancelled) {
          setServerTransactions([]);
          setTransactionPagination(null);
          setFilterError(error.message || "Could not load filtered transactions.");
        }
      } finally {
        if (!cancelled) setFilterLoading(false);
      }
    }, query.trim() ? 250 : 0);

    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [
    page,
    filter,
    dateFilter,
    categoryFilter,
    query,
    sortOrder,
    filterReload,
    transactionPage,
  ]);
  const visible = useMemo(() => {
    const rows = serverTransactions ?? transactions;
    return [...rows].sort((first, second) => {
      if (sortOrder === "oldest") {
        return String(first.date).localeCompare(String(second.date));
      }
      if (sortOrder === "amount_high") {
        return Number(second.amount) - Number(first.amount);
      }
      if (sortOrder === "amount_low") {
        return Number(first.amount) - Number(second.amount);
      }
      return String(second.date).localeCompare(String(first.date));
    });
  }, [transactions, serverTransactions, sortOrder]);
  const toast = (message) => {
    setNotice(message);
    setTimeout(() => setNotice(""), 2600);
  };
  const saveProfile = async (event) => {
    event.preventDefault();
    setProfileError("");
    setProfileSaving(true);

    try {
      const response = await api.updateProfile({
        name: profileName.trim(),
        email: profileEmail.trim(),
      });
      onUserUpdated(response.user);
      setProfileEditing(false);
      toast("Profile updated successfully.");
    } catch (error) {
      setProfileError(error.message || "Could not update your profile.");
    } finally {
      setProfileSaving(false);
    }
  };
  const saveProfilePhoto = async (event) => {
    const photo = event.target.files?.[0];
    event.target.value = "";
    if (!photo) return;

    setProfileError("");
    setProfilePhotoSaving(true);
    try {
      const response = await api.updateProfilePhoto(photo);
      onUserUpdated(response.user);
      toast("Profile photo updated successfully.");
    } catch (error) {
      setProfileError(error.message || "Could not update your profile photo.");
    } finally {
      setProfilePhotoSaving(false);
    }
  };
  const removeProfilePhoto = async () => {
    setProfileError("");
    setProfilePhotoSaving(true);
    try {
      const response = await api.deleteProfilePhoto();
      onUserUpdated(response.user);
      toast("Profile photo removed.");
    } catch (error) {
      setProfileError(error.message || "Could not remove your profile photo.");
    } finally {
      setProfilePhotoSaving(false);
    }
  };
  const savePassword = async (event) => {
    event.preventDefault();
    setPasswordError("");
    setPasswordSaving(true);

    try {
      await api.updatePassword({
        current_password: currentPassword,
        password: newPassword,
        password_confirmation: newPasswordConfirmation,
      });
      setCurrentPassword("");
      setNewPassword("");
      setNewPasswordConfirmation("");
      setPasswordEditing(false);
      toast("Password changed successfully.");
    } catch (error) {
      setPasswordError(error.message || "Could not change your password.");
    } finally {
      setPasswordSaving(false);
    }
  };
  const downloadBackup = async () => {
    setBackupDownloading(true);
    try {
      const backup = await api.getBackup();
      const file = new Blob([JSON.stringify(backup, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(file);
      const link = document.createElement("a");
      link.href = url;
      link.download = `kharcha-backup-${new Date().toISOString().slice(0, 10)}.json`;
      link.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      toast("Your Kharcha backup is downloaded.");
    } catch (error) {
      toast(error.message || "Could not download your backup.");
    } finally {
      setBackupDownloading(false);
    }
  };
  const restoreBackup = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast("Choose a backup smaller than 5 MB.");
      return;
    }

    let backup;
    try {
      backup = JSON.parse(await file.text());
    } catch {
      toast("That file is not a readable Kharcha backup.");
      return;
    }

    if (backup?.format !== "kharcha-backup-v1") {
      toast("This backup format is not supported.");
      return;
    }
    const confirmation = window.prompt(
      "Restore replaces the records currently in this account with the selected backup. Type RESTORE to continue.",
    );
    if (confirmation !== "RESTORE") return;

    setBackupRestoring(true);
    try {
      await api.restoreBackup(backup);
      toast("Backup restored. Reloading your account…");
      window.location.reload();
    } catch (error) {
      toast(error.message || "Could not restore this backup.");
    } finally {
      setBackupRestoring(false);
    }
  };
  const openTransactionModal = (transaction = null) => {
    setEditingTransaction(transaction);
    setForm(
      transaction
        ? {
            name: transaction.name || transaction.description || "",
            category: transaction.category || "Other",
            amount: String(transaction.amount ?? ""),
            kind: transaction.kind || transaction.type || "expense",
            date: String(transaction.date || "").slice(0, 10),
          }
        : {
            name: "",
            category: categories[0]?.name || "Other",
            amount: "",
            kind: "expense",
            date: new Date().toISOString().slice(0, 10),
          },
    );
    setModal(true);
  };
  const addTransaction = async (e) => {
    e.preventDefault();
    const item = {
      ...form,
      id: editingTransaction?.id || Date.now(),
      amount: Number(form.amount),
      description: form.name,
      type: form.kind,
      icon: form.kind === "income" ? "↗" : "◈",
      color: "mint",
    };
    try {
      if (!Number.isNaN(Number(form.amount))) {
        if (editingTransaction) {
          await api.updateTransaction(editingTransaction.id, item);
        } else {
          await api.createTransaction(item);
        }
      }
    } catch (error) {
      toast(error.message);
      return;
    }
    setTransactions((current) =>
      editingTransaction
        ? current.map((transaction) =>
            transaction.id === editingTransaction.id ? item : transaction,
          )
        : [item, ...current],
    );
    setFilterReload((current) => current + 1);
    setTransactionPage(1);
    setModal(false);
    setEditingTransaction(null);
    await loadSummary();
    const budgets = await loadOverviewBudgets();
    const affectedBudget = item.kind === "expense"
      ? budgets.find((budget) => budget.category === item.category && Number(budget.percentage) >= 80)
      : null;
    if (affectedBudget && Number(affectedBudget.percentage) >= 100) {
      toast(`${item.category} budget exceeded (${Math.round(affectedBudget.percentage)}%).`);
    } else if (affectedBudget) {
      toast(`${item.category} budget is ${Math.round(affectedBudget.percentage)}% used.`);
    } else {
      toast(editingTransaction ? "Transaction updated" : "Transaction added");
    }
  };
  const remove = async (id) => {
    try {
      await api.deleteTransaction(id);
    } catch (error) {
      if (!error.message.includes("Failed to fetch")) toast(error.message);
    }
    setTransactions(transactions.filter((t) => t.id !== id));
    setFilterReload((current) => current + 1);
    setTransactionPage(1);
    await loadSummary();
    await loadOverviewBudgets();
    toast("Transaction removed");
  };

  const buildTransactionExportFilters = () => {
    const filters = {
      type: filter === "All" ? "" : filter.toLowerCase(),
      category: categoryFilter === "all" ? "" : categoryFilter,
      search: query.trim(),
      sort: sortOrder,
    };
    const now = new Date();
    const formatDate = (date) =>
      `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
    if (dateFilter === "this_month") {
      filters.from = formatDate(new Date(now.getFullYear(), now.getMonth(), 1));
      filters.to = formatDate(
        new Date(now.getFullYear(), now.getMonth() + 1, 0),
      );
    } else if (dateFilter === "last_month") {
      filters.from = formatDate(
        new Date(now.getFullYear(), now.getMonth() - 1, 1),
      );
      filters.to = formatDate(new Date(now.getFullYear(), now.getMonth(), 0));
    } else if (dateFilter === "this_year") {
      filters.from = `${now.getFullYear()}-01-01`;
      filters.to = `${now.getFullYear()}-12-31`;
    }
    return filters;
  };

  const getTransactionExportRows = async () => {
    const response = await api.getTransactions(buildTransactionExportFilters());
    const rows = Array.isArray(response) ? response : response?.data || [];
    return rows.map((transaction) => ({
      date: transaction.date,
      description: transaction.name || transaction.description || "Transaction",
      category: transaction.category?.name || transaction.category || "Other",
      type: transaction.kind || transaction.type || "expense",
      amount: Number(transaction.amount) || 0,
    }));
  };

  const exportTransactions = async () => {

    let exportRows;
    try {
      exportRows = await getTransactionExportRows();
    } catch (error) {
      toast(error.message || "Could not export transactions.");
      return;
    }

    const csvCell = (value) => {
      let safeValue = String(value ?? "");
      if (/^[=+@]/.test(safeValue) || (/^-/.test(safeValue) && !/^-?\d+(\.\d+)?$/.test(safeValue))) safeValue = `'${safeValue}`;
      return `"${safeValue.replaceAll('"', '""')}"`;
    };
    const filters = buildTransactionExportFilters();
    const totalIncome = exportRows.filter((row) => row.type === "income").reduce((sum, row) => sum + row.amount, 0);
    const totalExpenses = exportRows.filter((row) => row.type === "expense").reduce((sum, row) => sum + row.amount, 0);
    const rows = [
      ["KHARCHA — TRANSACTION STATEMENT"],
      ["Account", user.name],
      ["Generated on", new Date().toLocaleString("en-IN")],
      ["Filters", [filters.from && `From ${filters.from}`, filters.to && `To ${filters.to}`, filters.category && `Category: ${filters.category}`, filters.type && `Type: ${filters.type}`, filters.search && `Search: ${filters.search}`].filter(Boolean).join(" · ") || "All transactions"],
      [],
      ["SUMMARY"],
      ["Transactions", exportRows.length],
      ["Total income (INR)", totalIncome.toFixed(2)],
      ["Total expenses (INR)", totalExpenses.toFixed(2)],
      ["Net balance (INR)", (totalIncome - totalExpenses).toFixed(2)],
      [],
      ["Date", "Description", "Category", "Type", "Amount"],
      ...exportRows.map((transaction) => [transaction.date, transaction.description, transaction.category, transaction.type, transaction.amount.toFixed(2)]),
      [],
      ["TOTAL INCOME (INR)", totalIncome.toFixed(2)],
      ["TOTAL EXPENSES (INR)", totalExpenses.toFixed(2)],
      ["NET BALANCE (INR)", (totalIncome - totalExpenses).toFixed(2)],
    ];
    const csv = `\uFEFF${rows.map((row) => row.map(csvCell).join(",")).join("\r\n")}`;
    const file = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(file);
    const link = document.createElement("a");
    link.href = url;
    link.download = `kharcha-transactions-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    toast("Transaction statement downloaded.");
  };

  const printTransactions = async () => {
    const printWindow = window.open("about:blank", "_blank");
    if (!printWindow) {
      toast("Allow pop-ups for Kharcha to save this PDF report.");
      return;
    }
    try {
      const rows = await getTransactionExportRows();
      const totalIncome = rows.filter((row) => row.type === "income").reduce((sum, row) => sum + row.amount, 0);
      const totalExpenses = rows.filter((row) => row.type === "expense").reduce((sum, row) => sum + row.amount, 0);
      const filters = buildTransactionExportFilters();
      const safe = (value) => String(value ?? "").replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]);
      const filterLabel = [filters.from && `From ${filters.from}`, filters.to && `To ${filters.to}`, filters.category && `Category: ${filters.category}`, filters.type && `Type: ${filters.type}`, filters.search && `Search: ${filters.search}`].filter(Boolean).join(" · ") || "All transactions";
      const html = `<!doctype html><html><head><meta charset="utf-8"><title>Kharcha Transaction Statement</title><style>
        @page{size:A4;margin:16mm}*{box-sizing:border-box}body{font:14px Arial,sans-serif;color:#24342b;margin:0}.brand{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #246d4c;padding-bottom:16px}.brand h1{font-size:25px;margin:0 0 5px}.brand p,.meta{color:#69766e;font-size:11px;margin:0}.badge{color:#246d4c;font-weight:bold;letter-spacing:2px;font-size:11px}.meta{margin:15px 0 20px;line-height:1.8}.summary{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:20px}.summary div{border:1px solid #dce6de;border-radius:8px;padding:12px}.summary small{display:block;color:#6e7d73;font-size:9px;text-transform:uppercase;letter-spacing:1px;margin-bottom:7px}.summary b{font-size:16px}table{width:100%;border-collapse:collapse;font-size:11px}thead{background:#246d4c;color:white}th,td{text-align:left;padding:9px 8px;border-bottom:1px solid #e4eae5}th:last-child,td:last-child{text-align:right}.amount{font-weight:bold;white-space:nowrap}.income{color:#26734e}.expense{color:#a94d42}.footer{border-top:1px solid #dce6de;margin-top:20px;padding-top:10px;color:#78847c;font-size:10px}.actions{margin:18px 0}.actions button{border:0;border-radius:6px;background:#246d4c;color:#fff;padding:10px 16px;font-weight:bold}@media print{.actions{display:none}tr{break-inside:avoid}}
      </style></head><body><header class="brand"><div><h1>Kharcha</h1><p>Personal finance transaction statement</p></div><span class="badge">TRANSACTION REPORT</span></header><div class="meta"><b>Account:</b> ${safe(user.name)}<br><b>Prepared:</b> ${safe(new Date().toLocaleString("en-IN"))}<br><b>Included records:</b> ${rows.length}<br><b>Filters:</b> ${safe(filterLabel)}</div><section class="summary"><div><small>Total income</small><b>₹${totalIncome.toLocaleString("en-IN", { minimumFractionDigits: 2 })}</b></div><div><small>Total expenses</small><b>₹${totalExpenses.toLocaleString("en-IN", { minimumFractionDigits: 2 })}</b></div><div><small>Net balance</small><b>₹${(totalIncome - totalExpenses).toLocaleString("en-IN", { minimumFractionDigits: 2 })}</b></div></section><table><thead><tr><th>Date</th><th>Description</th><th>Category</th><th>Type</th><th>Amount (₹)</th></tr></thead><tbody>${rows.map((row) => `<tr><td>${safe(row.date)}</td><td>${safe(row.description)}</td><td>${safe(row.category)}</td><td class="${row.type === "income" ? "income" : "expense"}">${safe(row.type)}</td><td class="amount">${row.amount.toLocaleString("en-IN", { minimumFractionDigits: 2 })}</td></tr>`).join("") || '<tr><td colspan="5">No transactions found for the selected filters.</td></tr>'}</tbody></table><footer class="footer">This report was generated from your Kharcha account. Keep it private as it contains personal financial information.</footer><div class="actions"><button onclick="window.print()">Print / Save as PDF</button></div><script>window.addEventListener('load',()=>setTimeout(()=>window.print(),250))</script></body></html>`;
      printWindow.document.open();
      printWindow.document.write(html);
      printWindow.document.close();
    } catch (error) {
      printWindow.close();
      toast(error.message || "Could not prepare the transaction report.");
    }
  };

  const openCategoryModal = (category = null) => {
    setEditingCategory(category);
    setCategoryName(category?.name || "");
    setCategoryModal(true);
  };

  const saveCategory = async (event) => {
    event.preventDefault();
    const name = categoryName.trim();
    if (!name) return;

    try {
      if (editingCategory) {
        const updated = await api.updateCategory(editingCategory.id, name);
        setCategories((current) =>
          current.map((category) =>
            category.id === updated.id ? updated : category,
          ),
        );
        toast("Category updated");
      } else {
        const created = await api.createCategory(name);
        setCategories((current) =>
          [...current, created].sort((a, b) => a.name.localeCompare(b.name)),
        );
        setForm((current) =>
          current.category === "Other"
            ? { ...current, category: created.name }
            : current,
        );
        toast("Category added");
      }
      setCategoryName("");
      setEditingCategory(null);
      setCategoryModal(false);
    } catch (error) {
      toast(error.message || "Could not save category.");
    }
  };

  const removeCategory = async (category) => {
    if (!window.confirm(`Delete “${category.name}”?`)) return;

    try {
      await api.deleteCategory(category.id);
      const remaining = categories.filter((item) => item.id !== category.id);
      setCategories(remaining);
      setForm((current) =>
        current.category === category.name
          ? { ...current, category: remaining[0]?.name || "Other" }
          : current,
      );
      toast("Category deleted");
    } catch (error) {
      toast(error.message || "Could not delete category.");
    }
  };

  const loadCategories = async () => {
    setCategoryLoading(true);
    setCategoryError("");

    try {
      const response = await api.getCategories();
      const rows = Array.isArray(response) ? response : response.data || [];

      setCategories(rows);

      if (rows.length > 0) {
        setForm((current) => ({
          ...current,
          category:
            current.category === "Other" ? rows[0].name : current.category,
        }));
      }
    } catch (error) {
      setCategoryError(error.message || "Could not load categories.");
    } finally {
      setCategoryLoading(false);
    }
  };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <a
          className="brand"
          href="#home"
          onClick={(e) => {
            e.preventDefault();
            setPage("Overview");
          }}
        >
          <span className="brand-mark">k</span>
          <span>
            kharcha<span className="brand-dot">.</span>
          </span>
        </a>
        <div className="workspace-label">WORKSPACE</div>
        <div className="workspace">
          <UserAvatar user={user} className="small" />
          <span>
            <b>{user.name}</b>
            <small>Personal account</small>
          </span>
          <span className="chevron">⌄</span>
        </div>
        <div className="nav-label">MENU</div>
        <nav>
          {nav.map((item) => (
            <button
              key={item.id}
              className={`nav-item ${page === item.id ? "active" : ""}`}
              onClick={() => setPage(item.id)}
            >
              <Icon>{item.icon}</Icon>
              {item.id}
              {item.id === "Transactions" && (
                <span className="nav-count">{transactions.length}</span>
              )}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <button
            className="nav-item profile-link"
            onClick={() => setPage("Profile")}
          >
            <UserAvatar user={user} />
            <span className="profile-meta">
              <b>{user.name}</b>
              <small>{user.email}</small>
            </span>
            <span className="more">···</span>
          </button>
          <div className="owner-credit">
            Created by <strong>Vishnu Shivaji Amdapure</strong>
          </div>
        </div>
      </aside>
      <main className="main-content">
        <header className="topbar">
          <div className="breadcrumb">
            Workspace <span>/</span> <b>{page}</b>
          </div>
          <div className="top-actions">
            <button
              className="icon-button"
              aria-label="Search"
              onClick={() =>
                document.querySelector(".search-box input")?.focus()
              }
            >
              ⌕
            </button>
            <button
              className="icon-button notification"
              aria-label="Notifications"
              onClick={() => {
                setPage("Overview");
                toast("Dashboard var tumche lending due reminders distil.");
              }}
            >
              ♧<i />
            </button>
            <span className="top-divider" />
            <button className="avatar" onClick={() => setPage("Profile")} aria-label="Open profile">
              {user.profile_photo ? <img src={user.profile_photo} alt="" /> : user.name.slice(0, 1).toUpperCase()}
            </button>
          </div>
        </header>
        <div className="page-wrap">
          {page === "Overview" && (
            <>
              <div className="page-heading">
                <div>
                  <div className="eyebrow">
                    <span className="live-dot" /> YOUR MONEY, AT A GLANCE
                  </div>
                  <h1>
                    Welcome, {user.name.split(" ")[0]}{" "}
                    <span className="wave">✳</span>
                  </h1>
                  <p>Here’s what’s happening with your money this month.</p>
                </div>
                <button
                  className="primary-button"
                  onClick={() => openTransactionModal()}
                >
                  <span>＋</span> Add transaction
                </button>
              </div>
              {apiError && (
                <div className="api-alert">
                  <span>!</span>
                  <div>
                    <b>Laravel API is not connected</b>
                    <small>
                      {apiError} Check <code>VITE_API_URL</code> and make sure
                      your Laravel server is running.
                    </small>
                  </div>
                  <button onClick={loadTransactions}>Retry</button>
                </div>
              )}
              <DueReminders userId={user.id} onOpenLending={() => setPage("Lending")} />
              <section className="summary-grid">
                <div className="summary-card balance-card">
                  <div className="card-top">
                    <span className="card-label">TOTAL BALANCE</span>
                    <button className="dots">···</button>
                  </div>
                  <div className="balance-value">{money(displayedBalance)}</div>
                  <div className="balance-foot">
                    <span className="trend-pill">LIVE</span>
                    <span>based on loaded transactions</span>
                    <div className="sparkline">
                      <svg viewBox="0 0 112 36" aria-hidden="true">
                        <path
                          d="M1 29 C13 23,15 32,26 22 S41 28,48 17 S62 23,68 12 S79 19,88 11 S101 13,111 4"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2.5"
                          strokeLinecap="round"
                        />
                      </svg>
                    </div>
                  </div>
                </div>
                <div className="summary-card">
                  <div className="card-top">
                    <span className="card-label">INCOME</span>
                    <span className="metric-icon income-icon">↙</span>
                  </div>
                  <div className="metric-value">{money(displayedIncome)}</div>
                  <div className="metric-caption">
                    <span className="trend-text">↗ 12.5%</span>{" "}
                    <span>vs. last month</span>
                  </div>
                  <div className="mini-bars income-bars">
                    {[
                      26, 36, 30, 44, 34, 52, 39, 55, 43, 63, 54, 74, 58, 82,
                    ].map((h, i) => (
                      <i key={i} style={{ height: `${h}%` }} />
                    ))}
                  </div>
                </div>
                <div className="summary-card">
                  <div className="card-top">
                    <span className="card-label">EXPENSES</span>
                    <span className="metric-icon expense-icon">↗</span>
                  </div>
                  <div className="metric-value">{money(displayedExpenses)}</div>
                  <div className="metric-caption">
                    <span className="down-text">↘ 4.3%</span>{" "}
                    <span>vs. last month</span>
                  </div>
                  <div className="mini-bars expense-bars">
                    {[
                      58, 73, 48, 82, 63, 44, 71, 54, 67, 42, 58, 37, 48, 32,
                    ].map((h, i) => (
                      <i key={i} style={{ height: `${h}%` }} />
                    ))}
                  </div>
                </div>
              </section>
              <section className="content-grid">
                <div className="panel transactions-panel">
                  <div className="panel-heading">
                    <div>
                      <h2>Recent transactions</h2>
                      <p>Your latest money moves</p>
                    </div>
                    <button
                      className="text-link"
                      onClick={() => setPage("Transactions")}
                    >
                      View all <span>→</span>
                    </button>
                  </div>
                  <div className="transaction-list">
                    {loading ? (
                      <div className="inline-state">Loading transactions…</div>
                    ) : transactions.length ? (
                      transactions
                        .slice(0, 5)
                        .map((t) => (
                          <TransactionRow
                            key={t.id}
                            item={t}
                            onDelete={remove}
                          />
                        ))
                    ) : (
                      <div className="inline-state">
                        No transactions yet. Add one to get started.
                      </div>
                    )}
                  </div>
                  <button
                    className="load-more"
                    onClick={() => setPage("Transactions")}
                  >
                    See all transactions <span>→</span>
                  </button>
                </div>
                <div className="panel spending-panel">
                  <div className="panel-heading">
                    <div>
                      <h2>Spending by category</h2>
                      <p>Where your money goes</p>
                    </div>
                    <select
                      className="period-select"
                      value={categoryPeriod}
                      onChange={(event) =>
                        setCategoryPeriod(event.target.value)
                      }
                      aria-label="Choose category spending period"
                    >
                      <option value="this_month">This month</option>
                      <option value="last_month">Last month</option>
                      <option value="this_year">This year</option>
                      <option value="all_time">All time</option>
                    </select>
                  </div>
                  <div className="spending-total">
                    <span>{money(categorySpendingTotal)}</span>
                    <small>total spent</small>
                  </div>
                  {displayedCategorySpending.length > 0 ? (
                    <>
                      <div
                        className="stacked-bar"
                        aria-label="Spending by category"
                      >
                        {displayedCategorySpending.map((category, index) => (
                          <i
                            key={category.name}
                            title={`${category.name}: ${money(category.amount)}`}
                            style={{
                              width: `${(category.amount / categorySpendingTotal) * 100}%`,
                              backgroundColor:
                                categoryColors[index % categoryColors.length],
                            }}
                          />
                        ))}
                      </div>
                      <div className="category-list">
                        {displayedCategorySpending
                          .slice(0, 5)
                          .map((category, index) => (
                            <div className="category-row" key={category.name}>
                              <span
                                className="category-dot"
                                style={{
                                  backgroundColor:
                                    categoryColors[
                                      index % categoryColors.length
                                    ],
                                }}
                              />
                              <span className="category-name">
                                {category.name}
                              </span>
                              <span className="category-amount">
                                {money(category.amount)}
                              </span>
                              <span className="category-percent">
                                {Math.round(
                                  (category.amount / categorySpendingTotal) *
                                    100,
                                )}
                                %
                              </span>
                            </div>
                          ))}
                      </div>
                    </>
                  ) : (
                    <div className="inline-state">
                      No expenses recorded this month yet.
                    </div>
                  )}
                  <button
                    className="load-more"
                    onClick={() => setPage("Categories")}
                  >
                    All categories <span>→</span>
                  </button>
                </div>
              </section>
              <section className="panel budget-overview-panel">
                <div className="panel-heading">
                  <div>
                    <h2>Monthly budget status</h2>
                    <p>Keep this month’s category spending on track</p>
                  </div>
                  <button
                    className="text-link"
                    onClick={() => setPage("Budgets")}
                  >
                    View budgets <span>→</span>
                  </button>
                </div>
                {overviewBudgetLoading ? (
                  <div className="inline-state">Loading budgets…</div>
                ) : overviewBudgetError ? (
                  <div className="inline-state">{overviewBudgetError}</div>
                ) : overviewBudgets.length ? (
                  <div className="overview-budget-list">
                    {overviewBudgets.slice(0, 4).map((budget) => {
                      const isOver = Number(budget.percentage) > 100;
                      const progress = Math.min(
                        Number(budget.percentage) || 0,
                        100,
                      );

                      return (
                        <div className="overview-budget-row" key={budget.id}>
                          <div className="overview-budget-labels">
                            <b>{budget.category}</b>
                            <span>
                              {money(budget.spent)} of {money(budget.amount)}
                            </span>
                          </div>
                          <div className="budget-progress-track">
                            <span
                              className={isOver ? "over-budget" : ""}
                              style={{ width: `${progress}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="inline-state">
                    No budgets set for this month yet.
                    <button
                      className="text-link"
                      onClick={() => setPage("Budgets")}
                    >
                      Add a budget <span>→</span>
                    </button>
                  </div>
                )}
              </section>
              <section className="panel cashflow-panel">
                <div className="panel-heading">
                  <div>
                    <h2>Cash flow</h2>
                    <p>Income and expenses over time</p>
                  </div>
                </div>
                <div
                  className="chart-wrap"
                  aria-label="Income and expenses for the last six months"
                >
                  <div className="chart-area">
                    <div className="grid-lines" aria-hidden="true">
                      <i />
                      <i />
                      <i />
                      <i />
                    </div>
                    <div className="bar-chart">
                      {displayedCashFlow.months.map((month) => (
                        <div className="bar-group" key={month.key}>
                          <div className="bars">
                            <i
                              className="bar income-bar"
                              style={{
                                height: `${(month.income / displayedCashFlow.maxAmount) * 100}%`,
                              }}
                              title={`${month.label} income: ${money(month.income)}`}
                            />
                            <i
                              className="bar expense-bar"
                              style={{
                                height: `${(month.expenses / displayedCashFlow.maxAmount) * 100}%`,
                              }}
                              title={`${month.label} expenses: ${money(month.expenses)}`}
                            />
                          </div>
                          <span>{month.label}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="chart-legend">
                  <span>
                    <i className="legend-income" /> Income
                  </span>
                  <span>
                    <i className="legend-expense" /> Expenses
                  </span>
                </div>
              </section>
            </>
          )}
          {page === "Transactions" && (
            <>
              <div className="page-heading">
                <div>
                  <div className="eyebrow">
                    <span className="live-dot" /> YOUR ACTIVITY
                  </div>
                  <h1>Transactions</h1>
                  <p>A clear view of every rupee in and out.</p>
                </div>
                <button
                  className="primary-button"
                  onClick={() => openTransactionModal()}
                >
                  <span>＋</span> Add transaction
                </button>
              </div>
              <div className="panel full-panel">
                <div className="toolbar">
                  <div className="search-box">
                    <span>⌕</span>
                    <input
                      placeholder="Search transactions..."
                      value={query}
                      onChange={(e) => {
                        setQuery(e.target.value);
                        setTransactionPage(1);
                      }}
                    />
                    <kbd>⌘ K</kbd>
                  </div>
                  <div className="filter-tabs">
                    {["All", "Expense", "Income"].map((f) => (
                      <button
                        key={f}
                        onClick={() => {
                          setFilter(f);
                          setTransactionPage(1);
                        }}
                        className={filter === f ? "selected" : ""}
                      >
                        {f}
                      </button>
                    ))}
                  </div>
                  <select
                    className="filter-button"
                    value={dateFilter}
                    onChange={(event) => {
                      setDateFilter(event.target.value);
                      setTransactionPage(1);
                    }}
                    aria-label="Filter transactions by date"
                  >
                    <option value="all">☷ All time</option>
                    <option value="this_month">This month</option>
                    <option value="last_month">Last month</option>
                    <option value="this_year">This year</option>
                  </select>
                  <select
                    className="filter-button category-filter"
                    value={categoryFilter}
                    onChange={(event) => {
                      setCategoryFilter(event.target.value);
                      setTransactionPage(1);
                    }}
                    aria-label="Filter transactions by category"
                  >
                    <option value="all">All categories</option>
                    {categories.map((category) => (
                      <option key={category.id} value={category.name}>
                        {category.name}
                      </option>
                    ))}
                  </select>
                  <select
                    className="filter-button sort-filter"
                    value={sortOrder}
                    onChange={(event) => {
                      setSortOrder(event.target.value);
                      setTransactionPage(1);
                    }}
                    aria-label="Sort transactions"
                  >
                    <option value="newest">Newest first</option>
                    <option value="oldest">Oldest first</option>
                    <option value="amount_high">Amount: high to low</option>
                    <option value="amount_low">Amount: low to high</option>
                  </select>
                  <button
                    className="filter-button export-button"
                    onClick={exportTransactions}
                    disabled={!visible.length}
                  >
                    ↓ Export CSV
                  </button>
                  <button
                    className="filter-button export-button print-report-button"
                    onClick={printTransactions}
                  >
                    ▤ Save as PDF
                  </button>
                </div>
                {filterError && (
                  <div className="api-alert" role="alert">
                    <span>!</span>
                    <div>
                      <b>Transactions filter load zala nahi</b>
                      <small>{filterError}</small>
                    </div>
                  </div>
                )}
                {filterLoading && (
                  <div className="transaction-filter-loading">
                    Applying filters…
                  </div>
                )}
                <div className="table-head">
                  <span>TRANSACTION</span>
                  <span>CATEGORY</span>
                  <span>DATE</span>
                  <span>AMOUNT</span>
                  <span />
                </div>
                {visible.length ? (
                  visible.map((t) => (
                    <TransactionRow
                      key={t.id}
                      item={t}
                      onDelete={remove}
                      onEdit={openTransactionModal}
                      table
                    />
                  ))
                ) : (
                  <div className="empty-state">
                    <span>⌕</span>
                    <b>No transactions found</b>
                    <p>Try another search or add a new transaction.</p>
                    <button
                      className="primary-button"
                      onClick={() => openTransactionModal()}
                    >
                      ＋ Add transaction
                    </button>
                  </div>
                )}
                {transactionPagination && transactionPagination.total > 0 && (
                  <div className="transaction-pagination">
                    <span>
                      Showing{" "}
                      {(transactionPagination.currentPage - 1) *
                        transactionPagination.perPage +
                        1}
                      –
                      {Math.min(
                        transactionPagination.currentPage *
                          transactionPagination.perPage,
                        transactionPagination.total,
                      )}{" "}
                      of {transactionPagination.total}
                    </span>
                    <div>
                      <button
                        className="secondary-button"
                        disabled={transactionPage <= 1 || filterLoading}
                        onClick={() =>
                          setTransactionPage((current) => current - 1)
                        }
                      >
                        ← Previous
                      </button>
                      <small>
                        Page {transactionPagination.currentPage} of{" "}
                        {transactionPagination.lastPage}
                      </small>
                      <button
                        className="secondary-button"
                        disabled={
                          transactionPage >= transactionPagination.lastPage ||
                          filterLoading
                        }
                        onClick={() =>
                          setTransactionPage((current) => current + 1)
                        }
                      >
                        Next →
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </>
          )}
          {page === "Recurring" && (
            <RecurringPage
              categories={categories}
              toast={toast}
              onTransactionsChanged={async () => {
                await Promise.all([loadTransactions(), loadSummary(), loadOverviewBudgets()]);
              }}
            />
          )}
          {page === "Reports" && <MonthlyReportPage />}
          {page === "Categories" && (
            <>
              <div className="page-heading">
                <div>
                  <div className="eyebrow">
                    <span className="live-dot" /> SPENDING, SORTED
                  </div>
                  <h1>Categories</h1>
                  <p>Organize your transactions with spending categories.</p>
                </div>
                <button
                  className="primary-button"
                  onClick={() => openCategoryModal()}
                >
                  <span>＋</span> Add category
                </button>
              </div>

              {categoryError && (
                <div className="api-alert">
                  <span>!</span>
                  <div>
                    <b>Unable to load categories</b>
                    <small>{categoryError}</small>
                  </div>
                  <button onClick={loadCategories}>Try again</button>
                </div>
              )}

              {categoryLoading ? (
                <div className="panel inline-state">
                  Loading your categories…
                </div>
              ) : categories.length > 0 ? (
                <div className="category-cards">
                  {categories.map((category) => (
                    <div className="panel category-card" key={category.id}>
                      <div className="cat-card-top">
                        <span className="cat-icon">▦</span>
                        <div className="category-actions">
                          <button
                            className="secondary-button"
                            onClick={() => openCategoryModal(category)}
                          >
                            Edit
                          </button>
                          <button
                            className="secondary-button danger-button"
                            onClick={() => removeCategory(category)}
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                      <h3>{category.name}</h3>
                      <p className="category-hint">
                        Available when adding a transaction
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="panel empty-state">
                  <span>▦</span>
                  <b>No categories yet</b>
                  <p>Create your first category to organize your spending.</p>
                  <button
                    className="primary-button"
                    onClick={() => openCategoryModal()}
                  >
                    ＋ Add category
                  </button>
                </div>
              )}
            </>
          )}
          {page === "Lending" && <UdharPage toast={toast} />}
          {page === "Budgets" && (
            <BudgetsPage categories={categories} toast={toast} />
          )}
          {page === "Goals" && <SavingsGoalsPage toast={toast} />}

          {page === "Profile" && (
            <>
              <div className="page-heading">
                <div>
                  <div className="eyebrow">
                    <span className="live-dot" /> YOUR SPACE
                  </div>
                  <h1>Profile</h1>
                  <p>Manage your personal account details.</p>
                </div>
              </div>
              <div className="panel profile-panel">
                <div className="profile-hero">
                  <UserAvatar user={user} className="profile-avatar" />
                  <div>
                    <h2>{user.name}</h2>
                    <p>Personal account</p>
                    <div className="profile-photo-actions">
                      <input
                        ref={profilePhotoInput}
                        type="file"
                        accept="image/jpeg,image/png,image/webp"
                        onChange={saveProfilePhoto}
                        hidden
                      />
                      <button
                        type="button"
                        className="photo-action"
                        disabled={profilePhotoSaving}
                        onClick={() => profilePhotoInput.current?.click()}
                      >
                        {profilePhotoSaving ? "Saving…" : user.profile_photo ? "Change photo" : "Add photo"}
                      </button>
                      {user.profile_photo && (
                        <button
                          type="button"
                          className="photo-action remove"
                          disabled={profilePhotoSaving}
                          onClick={removeProfilePhoto}
                        >
                          Remove
                        </button>
                      )}
                      <small>JPG, PNG, or WebP · up to 1 MB</small>
                    </div>
                  </div>
                  <button
                    className="secondary-button"
                    onClick={() => {
                      setProfileName(user.name);
                      setProfileEmail(user.email);
                      setProfileError("");
                      setProfileEditing(!profileEditing);
                    }}
                  >
                    {profileEditing ? "Cancel" : "Edit profile"}
                  </button>
                </div>
                {profileError && (
                  <div className="auth-error" role="alert">
                    {profileError}
                  </div>
                )}
                {profileEditing ? (
                  <form
                    className="profile-edit-container"
                    onSubmit={saveProfile}
                  >
                    <label className="profile-field">
                      <span>FULL NAME</span>
                      <input
                        required
                        maxLength="100"
                        value={profileName}
                        onChange={(event) => setProfileName(event.target.value)}
                        aria-label="Full name"
                      />
                    </label>
                    <label className="profile-field">
                      <span>EMAIL ADDRESS</span>
                      <input
                        required
                        type="email"
                        maxLength="255"
                        value={profileEmail}
                        onChange={(event) =>
                          setProfileEmail(event.target.value)
                        }
                        aria-label="Email address"
                      />
                    </label>
                    <button
                      className="primary-button"
                      disabled={profileSaving || !profileName.trim()}
                    >
                      {profileSaving ? "Saving…" : "Save changes"}
                    </button>
                  </form>
                ) : (
                  <>
                    <div className="profile-field">
                      <span>FULL NAME</span>
                      <b>{user.name}</b>
                    </div>
                    <div className="profile-field">
                      <span>EMAIL ADDRESS</span>
                      <b>{user.email}</b>
                    </div>
                  </>
                )}
                <div className="profile-field">
                  <span>ACCOUNT TYPE</span>
                  <b>Personal</b>
                </div>
                <div className="profile-password-section">
                  <div className="profile-password-heading">
                    <div>
                      <b>Password</b>
                      <p>Keep your account secure with a strong password.</p>
                    </div>
                    <button
                      type="button"
                      className="secondary-button"
                      onClick={() => {
                        setPasswordError("");
                        setPasswordEditing(!passwordEditing);
                      }}
                    >
                      {passwordEditing ? "Cancel" : "Change password"}
                    </button>
                  </div>
                  {passwordError && (
                    <div className="auth-error" role="alert">
                      {passwordError}
                    </div>
                  )}
                  {passwordEditing && (
                    <form
                      className="profile-password-form"
                      onSubmit={savePassword}
                    >
                      <label>
                        Current password
                        <input
                          required
                          type={showProfilePasswords ? "text" : "password"}
                          autoComplete="current-password"
                          value={currentPassword}
                          onChange={(event) =>
                            setCurrentPassword(event.target.value)
                          }
                        />
                      </label>
                      <label>
                        New password
                        <input
                          required
                          minLength="8"
                          type={showProfilePasswords ? "text" : "password"}
                          autoComplete="new-password"
                          value={newPassword}
                          onChange={(event) =>
                            setNewPassword(event.target.value)
                          }
                        />
                      </label>
                      <label>
                        Confirm new password
                        <input
                          required
                          minLength="8"
                          type={showProfilePasswords ? "text" : "password"}
                          autoComplete="new-password"
                          value={newPasswordConfirmation}
                          onChange={(event) =>
                            setNewPasswordConfirmation(event.target.value)
                          }
                        />
                      </label>
                      <label className="profile-show-password">
                        <input
                          type="checkbox"
                          checked={showProfilePasswords}
                          onChange={(event) =>
                            setShowProfilePasswords(event.target.checked)
                          }
                        />
                        Show password
                      </label>
                      <button
                        className="primary-button"
                        disabled={passwordSaving}
                      >
                        {passwordSaving ? "Saving…" : "Save new password"}
                      </button>
                    </form>
                  )}
                </div>
                <div className="profile-password-section backup-section">
                  <div className="profile-password-heading">
                    <div>
                      <b>Data backup</b>
                      <p>Download your categories, transactions, budgets, savings goals, lending, and recurring schedules. This JSON file is for restoring your account; use Transactions or Reports for readable CSV and PDF sheets.</p>
                    </div>
                    <button
                      type="button"
                      className="secondary-button"
                      onClick={downloadBackup}
                      disabled={backupDownloading}
                    >
                      {backupDownloading ? "Preparing…" : "Download backup"}
                    </button>
                  </div>
                  <div className="profile-password-heading backup-restore-row">
                    <div>
                      <b>Restore backup</b>
                      <p>Replaces this account’s records with the selected Kharcha backup.</p>
                    </div>
                    <input
                      ref={backupFileInput}
                      className="visually-hidden-file-input"
                      type="file"
                      accept="application/json,.json"
                      onChange={restoreBackup}
                    />
                    <button
                      type="button"
                      className="secondary-button"
                      disabled={backupRestoring}
                      onClick={() => backupFileInput.current?.click()}
                    >
                      {backupRestoring ? "Restoring…" : "Choose backup"}
                    </button>
                  </div>
                </div>
                <button className="signout-button" onClick={onSignOut}>
                  Sign out <span>↗</span>
                </button>
              </div>
            </>
          )}
        </div>
      </main>
      <nav className="mobile-bottom-nav" aria-label="Main navigation">
        {[
          { id: "Overview", label: "Home", icon: "⌂" },
          { id: "Transactions", label: "Activity", icon: "⇄" },
          { id: "Budgets", label: "Budgets", icon: "◷" },
        ].map((item) => (
          <button
            key={item.id}
            className={`mobile-nav-item ${page === item.id ? "active" : ""}`}
            onClick={() => {
              setPage(item.id);
              setMobileMoreOpen(false);
            }}
            aria-current={page === item.id ? "page" : undefined}
          >
            <span aria-hidden="true">{item.icon}</span>
            <small>{item.label}</small>
          </button>
        ))}
        <button
          className={`mobile-nav-item ${mobileMoreOpen || !["Overview", "Transactions", "Budgets"].includes(page) ? "active" : ""}`}
          onClick={() => setMobileMoreOpen((open) => !open)}
          aria-expanded={mobileMoreOpen}
          aria-haspopup="menu"
        >
          <span aria-hidden="true">···</span>
          <small>More</small>
        </button>
      </nav>
      {mobileMoreOpen && (
        <>
          <button
            type="button"
            className="mobile-more-dismiss"
            aria-label="Close navigation menu"
            onClick={() => setMobileMoreOpen(false)}
          />
          <div className="mobile-more-menu" role="menu" aria-label="More pages">
            {[
              ...nav.filter((item) => !["Overview", "Transactions", "Budgets"].includes(item.id)),
              { id: "Profile", icon: "◉" },
            ].map((item) => (
              <button
                key={item.id}
                role="menuitem"
                className={page === item.id ? "active" : ""}
                onClick={() => {
                  setPage(item.id);
                  setMobileMoreOpen(false);
                }}
              >
                <span aria-hidden="true">{item.icon}</span>
                {item.id}
              </button>
            ))}
          </div>
        </>
      )}
      {modal && (
        <div
          className="modal-backdrop"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) {
              setModal(false);
              setEditingTransaction(null);
            }
          }}
        >
          <form className="modal" onSubmit={addTransaction}>
            <div className="modal-head">
              <div>
                <div className="eyebrow">
                  {editingTransaction ? "UPDATE MONEY MOVE" : "NEW MONEY MOVE"}
                </div>
                <h2>
                  {editingTransaction ? "Edit transaction" : "Add transaction"}
                </h2>
              </div>
              <button
                type="button"
                className="close-button"
                onClick={() => {
                  setModal(false);
                  setEditingTransaction(null);
                }}
              >
                ×
              </button>
            </div>

            <div className="type-switch">
              <button
                type="button"
                className={form.kind === "expense" ? "active" : ""}
                onClick={() => setForm({ ...form, kind: "expense" })}
              >
                ↗ Expense
              </button>
              <button
                type="button"
                className={form.kind === "income" ? "active income-active" : ""}
                onClick={() => setForm({ ...form, kind: "income" })}
              >
                ↙ Income
              </button>
            </div>

            <label>
              Description
              <input
                required
                placeholder="What was it for?"
                value={form.name}
                onChange={(event) =>
                  setForm({ ...form, name: event.target.value })
                }
              />
            </label>

            <div className="form-row">
              <label>
                Amount
                <input
                  required
                  min="1"
                  type="number"
                  placeholder="₹ 0"
                  value={form.amount}
                  onChange={(event) =>
                    setForm({ ...form, amount: event.target.value })
                  }
                />
              </label>
              <label>
                Date
                <input
                  required
                  type="date"
                  value={form.date}
                  onChange={(event) =>
                    setForm({ ...form, date: event.target.value })
                  }
                />
              </label>
            </div>

            <label>
              Category
              <select
                value={form.category}
                onChange={(event) =>
                  setForm({ ...form, category: event.target.value })
                }
              >
                {categories.length > 0 ? (
                  categories.map((category) => (
                    <option key={category.id} value={category.name}>
                      {category.name}
                    </option>
                  ))
                ) : (
                  <option value="Other">Other</option>
                )}
              </select>
            </label>

            <div className="modal-actions">
              <button
                type="button"
                className="secondary-button"
                onClick={() => {
                  setModal(false);
                  setEditingTransaction(null);
                }}
              >
                Cancel
              </button>
              <button className="primary-button" type="submit">
                {editingTransaction ? "Save changes" : "Save transaction"}{" "}
                <span>→</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {categoryModal && (
        <div
          className="modal-backdrop"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setCategoryModal(false);
          }}
        >
          <form className="modal" onSubmit={saveCategory}>
            <div className="modal-head">
              <div>
                <div className="eyebrow">ORGANIZE YOUR SPENDING</div>
                <h2>{editingCategory ? "Edit category" : "Add category"}</h2>
              </div>
              <button
                type="button"
                className="close-button"
                onClick={() => setCategoryModal(false)}
              >
                ×
              </button>
            </div>

            <label>
              Category name
              <input
                required
                maxLength="100"
                placeholder="e.g. Groceries"
                value={categoryName}
                onChange={(event) => setCategoryName(event.target.value)}
              />
            </label>

            <div className="modal-actions">
              <button
                type="button"
                className="secondary-button"
                onClick={() => setCategoryModal(false)}
              >
                Cancel
              </button>
              <button className="primary-button" type="submit">
                {editingCategory ? "Save changes" : "Save category"}{" "}
                <span>→</span>
              </button>
            </div>
          </form>
        </div>
      )}
      {notice && (
        <div className="toast">
          <span>✓</span>
          {notice}
        </div>
      )}
    </div>
  );
}

function App() {
  const [user, setUser] = useState(() => {
    if (new URLSearchParams(window.location.search).has("token")) return null;
    const storedUser = localStorage.getItem("kharcha_user");
    if (!localStorage.getItem("kharcha_token") || !storedUser) return null;

    try {
      return JSON.parse(storedUser);
    } catch {
      return null;
    }
  });

  const handleAuthenticated = (session) => {
    localStorage.setItem("kharcha_token", session.token);
    localStorage.setItem("kharcha_user", JSON.stringify(session.user));
    setUser(session.user);
  };

  const handleSignOut = async () => {
    try {
      await api.logout();
    } catch {
      // Clear the local session even if the server is unavailable.
    }
    localStorage.removeItem("kharcha_token");
    localStorage.removeItem("kharcha_user");
    setUser(null);
  };

  if (!user) return <AuthPage onAuthenticated={handleAuthenticated} />;

  const handleUserUpdated = (updatedUser) => {
    localStorage.setItem("kharcha_user", JSON.stringify(updatedUser));
    setUser(updatedUser);
  };

  return (
    <FinanceApp
      user={user}
      onSignOut={handleSignOut}
      onUserUpdated={handleUserUpdated}
    />
  );
}

function TransactionRow({ item: t, onDelete, onEdit, table = false }) {
  return (
    <div className={`transaction-row ${table ? "table-row" : ""}`}>
      <span className={`transaction-icon ${t.color || "mint"}`}>{t.icon}</span>
      <span className="transaction-info">
        <b>{t.name}</b>
        <small>{t.category}</small>
      </span>
      {table && <span className="table-category">{t.category}</span>}
      <span className="transaction-date">{prettyDate(t.date)}</span>
      <span className={`transaction-amount ${t.kind}`}>
        {t.kind === "income" ? "+" : "−"}
        {money(t.amount)}
      </span>
      {table && (
        <div className="row-actions">
          <button
            className="row-edit"
            aria-label="Edit transaction"
            title="Edit transaction"
            onClick={() => onEdit(t)}
          >
            ✎
          </button>
          <button
            className="row-delete"
            aria-label="Delete transaction"
            title="Delete transaction"
            onClick={() => onDelete(t.id)}
          >
            ×
          </button>
        </div>
      )}
    </div>
  );
}

export default App;
