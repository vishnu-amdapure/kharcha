import { useEffect, useState } from "react";
import { api } from "./api";

const formatMoney = (value) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(Number(value || 0));

const localDateKey = (date) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

const formatDate = (value) =>
  new Date(`${value}T12:00:00`).toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });

function DueReminders({ onOpenLending, userId }) {
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const preferenceKey = `kharcha_due_notifications_${userId || "user"}`;
  const [notificationsEnabled, setNotificationsEnabled] = useState(
    () => localStorage.getItem(preferenceKey) === "enabled",
  );

  const loadReminders = async () => {
    setLoading(true);
    setError("");
    try {
      const response = await api.getUdhars();
      setEntries(Array.isArray(response) ? response : response.data || []);
    } catch (requestError) {
      setError(requestError.message || "Reminders could not be loaded.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReminders();
  }, []);

  const today = localDateKey(new Date());
  const soon = new Date();
  soon.setDate(soon.getDate() + 7);
  const soonKey = localDateKey(soon);

  const reminders = entries
    .filter(
      (entry) =>
        entry.due_date && Number(entry.remaining_amount || 0) > 0 && entry.due_date <= soonKey,
    )
    .map((entry) => ({
      ...entry,
      reminderStatus:
        entry.due_date < today
          ? "Overdue"
          : entry.due_date === today
            ? "Due today"
            : "Due soon",
    }))
    .sort((first, second) => first.due_date.localeCompare(second.due_date));

  const enableNotifications = async () => {
    if (!("Notification" in window)) {
      setError("This browser does not support notifications.");
      return;
    }
    const permission = await Notification.requestPermission();
    if (permission !== "granted") {
      setError("Allow notifications in your browser settings to receive due-date reminders.");
      return;
    }
    localStorage.setItem(preferenceKey, "enabled");
    setNotificationsEnabled(true);
  };

  useEffect(() => {
    if (!notificationsEnabled || loading || !reminders.length || !("Notification" in window) || Notification.permission !== "granted") return;
    const todayKey = localDateKey(new Date());
    const sentKey = `kharcha_due_notification_sent_${userId || "user"}`;
    if (localStorage.getItem(sentKey) === todayKey) return;
    const title = "Kharcha due-date reminder";
    const options = {
      body: `${reminders.length} lending ${reminders.length === 1 ? "item is" : "items are"} due or overdue. Open Kharcha to review.`,
      icon: "/icons/kharcha-192.png",
      badge: "/icons/kharcha-192.png",
      tag: `kharcha-due-${todayKey}`,
    };
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.ready.then((registration) => registration.showNotification(title, options)).catch(() => {});
    } else {
      new Notification(title, options);
    }
    localStorage.setItem(sentKey, todayKey);
  }, [notificationsEnabled, loading, entries, reminders.length, userId]);

  return (
    <section className="due-reminders panel" aria-live="polite">
      <div className="due-reminders-heading">
        <div>
          <div className="eyebrow"><span className="live-dot" /> LENDING REMINDERS</div>
          <h2>Due dates to keep an eye on</h2>
          <p>Open amounts due today, in the next 7 days, or already overdue.</p>
        </div>
        <div className="due-reminder-actions">
          <button className="secondary-button" onClick={enableNotifications} disabled={notificationsEnabled}>
            {notificationsEnabled ? "Reminders enabled" : "Enable notifications"}
          </button>
          <button className="secondary-button" onClick={onOpenLending}>View lending →</button>
        </div>
      </div>

      {loading ? (
        <div className="inline-state">Loading reminders…</div>
      ) : error ? (
        <div className="due-reminder-error">
          <span>{error}</span>
          <button className="secondary-button" onClick={loadReminders}>Retry</button>
        </div>
      ) : reminders.length ? (
        <div className="due-reminder-list">
          {reminders.slice(0, 5).map((entry) => (
            <div className="due-reminder-row" key={entry.id}>
              <span className={`due-reminder-mark ${entry.direction}`}>
                {entry.direction === "given" ? "↙" : "↗"}
              </span>
              <div className="due-reminder-person">
                <strong>{entry.person_name}</strong>
                <small>
                  {entry.direction === "given" ? "Collect from" : "Repay to"} · {formatDate(entry.due_date)}
                </small>
              </div>
              <span className={`due-reminder-status ${entry.reminderStatus.toLowerCase().replace(" ", "-")}`}>
                {entry.reminderStatus}
              </span>
              <strong className="due-reminder-amount">{formatMoney(entry.remaining_amount)}</strong>
            </div>
          ))}
          {reminders.length > 5 && (
            <button className="due-reminder-more" onClick={onOpenLending}>
              +{reminders.length - 5} more · View all lending
            </button>
          )}
        </div>
      ) : (
        <div className="due-reminder-clear">
          <span>✓</span>
          <div><strong>You’re all caught up</strong><small>No open lending amounts are due within the next 7 days.</small></div>
        </div>
      )}
    </section>
  );
}

export default DueReminders;
