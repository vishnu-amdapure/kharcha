import { useEffect, useMemo, useState } from "react";
import { api } from "./api";

const today = () => new Date().toISOString().slice(0, 10);

const emptyEntry = () => ({
  person_name: "",
  direction: "given",
  amount: "",
  date: today(),
  due_date: "",
  note: "",
});

const emptyPayment = () => ({
  amount: "",
  date: today(),
  note: "",
});

const formatMoney = (value) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(Number(value) || 0);

const formatDate = (value) => {
  if (!value) return "No due date";

  return new Date(`${value}T12:00:00`).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
};

function UdharPage({ toast }) {
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState("all");
  const [entryModalOpen, setEntryModalOpen] = useState(false);
  const [paymentModalEntry, setPaymentModalEntry] = useState(null);
  const [editingEntry, setEditingEntry] = useState(null);
  const [entryForm, setEntryForm] = useState(emptyEntry());
  const [paymentForm, setPaymentForm] = useState(emptyPayment());
  const [saving, setSaving] = useState(false);

  const loadEntries = async () => {
    setLoading(true);
    setError("");

    try {
      const response = await api.getUdhars();
      const rows = Array.isArray(response) ? response : response.data || [];
      setEntries(rows);
    } catch (requestError) {
      setError(requestError.message || "Could not load lending records.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEntries();
  }, []);

  const visibleEntries = useMemo(
    () =>
      entries.filter((entry) => filter === "all" || entry.direction === filter),
    [entries, filter],
  );

  const toCollect = entries
    .filter((entry) => entry.direction === "given")
    .reduce((total, entry) => total + Number(entry.remaining_amount || 0), 0);

  const toRepay = entries
    .filter((entry) => entry.direction === "taken")
    .reduce((total, entry) => total + Number(entry.remaining_amount || 0), 0);

  const openEntryModal = (entry = null) => {
    setEditingEntry(entry);
    setEntryForm(entry ? { ...emptyEntry(), ...entry } : emptyEntry());
    setEntryModalOpen(true);
  };

  const saveEntry = async (event) => {
    event.preventDefault();
    setSaving(true);

    const payload = {
      person_name: entryForm.person_name.trim(),
      direction: entryForm.direction,
      amount: Number(entryForm.amount),
      date: entryForm.date,
      due_date: entryForm.due_date || null,
      note: entryForm.note.trim() || null,
    };

    try {
      if (editingEntry) {
        const updated = await api.updateUdhar(editingEntry.id, payload);
        setEntries((current) =>
          current.map((entry) => (entry.id === updated.id ? updated : entry)),
        );
        toast("Lending record updated");
      } else {
        const created = await api.createUdhar(payload);
        setEntries((current) => [created, ...current]);
        toast("Lending record added");
      }

      setEntryModalOpen(false);
      setEditingEntry(null);
    } catch (requestError) {
      toast(requestError.message || "Could not save this record.");
    } finally {
      setSaving(false);
    }
  };

  const removeEntry = async (entry) => {
    const confirmed = window.confirm(
      `Delete the lending record for ${entry.person_name}? Its repayment history will also be deleted.`,
    );

    if (!confirmed) return;

    try {
      await api.deleteUdhar(entry.id);
      setEntries((current) => current.filter((item) => item.id !== entry.id));
      toast("Lending record deleted");
    } catch (requestError) {
      toast(requestError.message || "Could not delete this record.");
    }
  };

  const openPaymentModal = (entry) => {
    setPaymentModalEntry(entry);
    setPaymentForm(emptyPayment());
  };

  const savePayment = async (event) => {
    event.preventDefault();
    setSaving(true);

    const payload = {
      ...paymentForm,
      amount: Number(paymentForm.amount),
      note: paymentForm.note.trim() || null,
    };

    try {
      const updated = await api.addUdharPayment(paymentModalEntry.id, payload);
      setEntries((current) =>
        current.map((entry) => (entry.id === updated.id ? updated : entry)),
      );
      setPaymentModalEntry(null);
      toast("Repayment recorded");
    } catch (requestError) {
      toast(requestError.message || "Could not record this repayment.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">
            <span className="live-dot" /> MONEY YOU OWE OR ARE OWED
          </div>
          <h1>Lending</h1>
          <p>Keep track of money lent, borrowed, and paid back.</p>
        </div>
        <button className="primary-button" onClick={() => openEntryModal()}>
          <span>＋</span> Add record
        </button>
      </div>

      {error && (
        <div className="api-alert">
          <span>!</span>
          <div>
            <b>Unable to load lending records</b>
            <small>{error}</small>
          </div>
          <button onClick={loadEntries}>Try again</button>
        </div>
      )}

      <section className="summary-grid udhar-summary-grid">
        <div className="summary-card udhar-summary-card receivable-card">
          <div className="card-top">
            <span className="card-label">TOTAL TO COLLECT</span>
            <span className="metric-icon income-icon">↙</span>
          </div>
          <div className="metric-value">{formatMoney(toCollect)}</div>
          <div className="metric-caption">Money people still owe you</div>
        </div>

        <div className="summary-card udhar-summary-card payable-card">
          <div className="card-top">
            <span className="card-label">TOTAL TO REPAY</span>
            <span className="metric-icon expense-icon">↗</span>
          </div>
          <div className="metric-value">{formatMoney(toRepay)}</div>
          <div className="metric-caption">Money you still owe people</div>
        </div>
      </section>

      <section className="panel udhar-panel">
        <div className="udhar-toolbar">
          <div>
            <h2>Lending records</h2>
            <p>Track balances and repayments for each person.</p>
          </div>

          <div className="filter-tabs">
            {[
              { id: "all", label: "All" },
              { id: "given", label: "You lent" },
              { id: "taken", label: "You borrowed" },
            ].map((item) => (
              <button
                key={item.id}
                className={filter === item.id ? "selected" : ""}
                onClick={() => setFilter(item.id)}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="inline-state">Loading lending records…</div>
        ) : visibleEntries.length > 0 ? (
          <div className="udhar-list">
            {visibleEntries.map((entry) => {
              const remaining = Number(entry.remaining_amount || 0);
              const paid = Number(entry.paid_amount || 0);
              const amount = Number(entry.amount || 0);
              const percentPaid =
                amount > 0 ? Math.min((paid / amount) * 100, 100) : 0;
              const directionLabel =
                entry.direction === "given" ? "You lent" : "You borrowed";

              return (
                <article className="udhar-card" key={entry.id}>
                  <div className="udhar-card-main">
                    <div className="udhar-person-icon">
                      {entry.person_name.slice(0, 1).toUpperCase()}
                    </div>

                    <div className="udhar-person-info">
                      <div className="udhar-card-title">
                        <h3>{entry.person_name}</h3>
                        <span className={`udhar-direction ${entry.direction}`}>
                          {directionLabel}
                        </span>
                      </div>
                      <p>
                        Added {formatDate(entry.date)}
                        {entry.due_date
                          ? ` · Due ${formatDate(entry.due_date)}`
                          : ""}
                      </p>
                      {entry.note && <p className="udhar-note">{entry.note}</p>}
                    </div>

                    <div className="udhar-remaining">
                      <small>{remaining === 0 ? "SETTLED" : "REMAINING"}</small>
                      <strong className={remaining === 0 ? "settled" : ""}>
                        {formatMoney(remaining)}
                      </strong>
                    </div>
                  </div>

                  <div className="udhar-progress-track">
                    <span style={{ width: `${percentPaid}%` }} />
                  </div>

                  <div className="udhar-card-bottom">
                    <span>
                      {formatMoney(paid)} repaid of {formatMoney(amount)}
                    </span>
                    <div className="udhar-actions">
                      {remaining > 0 && (
                        <button
                          className="small-primary-button"
                          onClick={() => openPaymentModal(entry)}
                        >
                          Record repayment
                        </button>
                      )}
                      <button
                        className="secondary-button"
                        onClick={() => openEntryModal(entry)}
                      >
                        Edit
                      </button>
                      <button
                        className="secondary-button danger-button"
                        onClick={() => removeEntry(entry)}
                      >
                        Delete
                      </button>
                    </div>
                  </div>

                  {entry.payments?.length > 0 && (
                    <details className="payment-history">
                      <summary>
                        Repayment history ({entry.payments.length})
                      </summary>
                      <div className="payment-history-list">
                        {entry.payments.map((payment) => (
                          <div className="payment-history-row" key={payment.id}>
                            <span>{formatDate(payment.date)}</span>
                            {payment.note && <small>{payment.note}</small>}
                            <b>{formatMoney(payment.amount)}</b>
                          </div>
                        ))}
                      </div>
                    </details>
                  )}
                </article>
              );
            })}
          </div>
        ) : (
          <div className="empty-state udhar-empty-state">
            <span>↔</span>
            <b>No lending records yet</b>
            <p>Add money you lent or borrowed to start tracking balances.</p>
            <button className="primary-button" onClick={() => openEntryModal()}>
              ＋ Add record
            </button>
          </div>
        )}
      </section>

      {entryModalOpen && (
        <div
          className="modal-backdrop"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setEntryModalOpen(false);
          }}
        >
          <form className="modal" onSubmit={saveEntry}>
            <div className="modal-head">
              <div>
                <div className="eyebrow">MONEY OWED</div>
                <h2>
                  {editingEntry ? "Edit lending record" : "Add lending record"}
                </h2>
              </div>
              <button
                type="button"
                className="close-button"
                onClick={() => setEntryModalOpen(false)}
              >
                ×
              </button>
            </div>

            <div className="type-switch udhar-type-switch">
              <button
                type="button"
                className={
                  entryForm.direction === "given" ? "active income-active" : ""
                }
                onClick={() =>
                  setEntryForm({ ...entryForm, direction: "given" })
                }
              >
                I lent money
              </button>
              <button
                type="button"
                className={entryForm.direction === "taken" ? "active" : ""}
                onClick={() =>
                  setEntryForm({ ...entryForm, direction: "taken" })
                }
              >
                I borrowed money
              </button>
            </div>

            <label>
              Person
              <input
                required
                maxLength="150"
                placeholder="Who is the money with?"
                value={entryForm.person_name}
                onChange={(event) =>
                  setEntryForm({
                    ...entryForm,
                    person_name: event.target.value,
                  })
                }
              />
            </label>

            <div className="form-row">
              <label>
                Amount
                <input
                  required
                  min={
                    editingEntry
                      ? Number(editingEntry.paid_amount || 0) || 0.01
                      : 0.01
                  }
                  step="0.01"
                  type="number"
                  placeholder="₹ 0"
                  value={entryForm.amount}
                  onChange={(event) =>
                    setEntryForm({ ...entryForm, amount: event.target.value })
                  }
                />
              </label>
              <label>
                Date
                <input
                  required
                  type="date"
                  value={entryForm.date}
                  onChange={(event) =>
                    setEntryForm({ ...entryForm, date: event.target.value })
                  }
                />
              </label>
            </div>

            <div className="form-row">
              <label>
                Due date <span className="optional-label">Optional</span>
                <input
                  type="date"
                  value={entryForm.due_date || ""}
                  onChange={(event) =>
                    setEntryForm({ ...entryForm, due_date: event.target.value })
                  }
                />
              </label>
              <label>
                Note <span className="optional-label">Optional</span>
                <input
                  maxLength="1000"
                  placeholder="Add a note"
                  value={entryForm.note || ""}
                  onChange={(event) =>
                    setEntryForm({ ...entryForm, note: event.target.value })
                  }
                />
              </label>
            </div>

            <div className="modal-actions">
              <button
                type="button"
                className="secondary-button"
                onClick={() => setEntryModalOpen(false)}
              >
                Cancel
              </button>
              <button
                className="primary-button"
                type="submit"
                disabled={saving}
              >
                {saving
                  ? "Saving…"
                  : editingEntry
                    ? "Save changes"
                    : "Save record"}
              </button>
            </div>
          </form>
        </div>
      )}

      {paymentModalEntry && (
        <div
          className="modal-backdrop"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget)
              setPaymentModalEntry(null);
          }}
        >
          <form className="modal" onSubmit={savePayment}>
            <div className="modal-head">
              <div>
                <div className="eyebrow">UPDATE THE BALANCE</div>
                <h2>Record repayment</h2>
                <p className="modal-subtitle">
                  {paymentModalEntry.person_name} ·{" "}
                  {formatMoney(paymentModalEntry.remaining_amount)} remaining
                </p>
              </div>
              <button
                type="button"
                className="close-button"
                onClick={() => setPaymentModalEntry(null)}
              >
                ×
              </button>
            </div>

            <label>
              Amount paid
              <input
                required
                min="0.01"
                max={paymentModalEntry.remaining_amount}
                step="0.01"
                type="number"
                placeholder="₹ 0"
                value={paymentForm.amount}
                onChange={(event) =>
                  setPaymentForm({ ...paymentForm, amount: event.target.value })
                }
              />
            </label>

            <div className="form-row">
              <label>
                Payment date
                <input
                  required
                  type="date"
                  value={paymentForm.date}
                  onChange={(event) =>
                    setPaymentForm({ ...paymentForm, date: event.target.value })
                  }
                />
              </label>
              <label>
                Note <span className="optional-label">Optional</span>
                <input
                  maxLength="500"
                  placeholder="Add a note"
                  value={paymentForm.note}
                  onChange={(event) =>
                    setPaymentForm({ ...paymentForm, note: event.target.value })
                  }
                />
              </label>
            </div>

            <div className="modal-actions">
              <button
                type="button"
                className="secondary-button"
                onClick={() => setPaymentModalEntry(null)}
              >
                Cancel
              </button>
              <button
                className="primary-button"
                type="submit"
                disabled={saving}
              >
                {saving ? "Saving…" : "Save repayment"}
              </button>
            </div>
          </form>
        </div>
      )}
    </>
  );
}

export default UdharPage;
