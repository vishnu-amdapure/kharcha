import { useEffect, useMemo, useState } from "react";
import { api } from "./api";

const currentMonth = () => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
};

const formatMoney = (amount) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(Number(amount) || 0);

function BudgetsPage({ categories, toast }) {
  const [budgets, setBudgets] = useState([]);
  const [selectedMonth, setSelectedMonth] = useState(currentMonth());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editingBudget, setEditingBudget] = useState(null);
  const [form, setForm] = useState({ category: "", amount: "" });
  const availableCategories = useMemo(
    () =>
      categories.filter(
        (category) =>
          !budgets.some(
            (budget) =>
              budget.category === category.name &&
              budget.id !== editingBudget?.id,
          ),
      ),
    [categories, budgets, editingBudget],
  );

  const loadBudgets = async (month = selectedMonth) => {
    setLoading(true);
    setError("");
    try {
      const response = await api.getBudgets(month);
      setBudgets(Array.isArray(response) ? response : response?.data || []);
    } catch (loadError) {
      setError(loadError.message || "Could not load budgets.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBudgets(selectedMonth);
  }, [selectedMonth]);

  const totals = useMemo(
    () =>
      budgets.reduce(
        (result, budget) => ({
          limit: result.limit + Number(budget.amount || 0),
          spent: result.spent + Number(budget.spent || 0),
        }),
        { limit: 0, spent: 0 },
      ),
    [budgets],
  );
  const budgetAlerts = budgets.filter(
    (budget) => Number(budget.percentage || 0) >= 80,
  );

  const openModal = (budget = null) => {
    setEditingBudget(budget);
    setForm(
      budget
        ? { category: budget.category, amount: String(budget.amount) }
        : { category: availableCategories[0]?.name || "", amount: "" },
    );
    setModalOpen(true);
  };

  const saveBudget = async (event) => {
    event.preventDefault();
    const payload = {
      ...form,
      month: selectedMonth,
      amount: Number(form.amount),
    };

    try {
      if (editingBudget) {
        await api.updateBudget(editingBudget.id, payload);
        toast("Budget updated");
      } else {
        await api.createBudget(payload);
        toast("Budget added");
      }
      setModalOpen(false);
      setEditingBudget(null);
      await loadBudgets(selectedMonth);
    } catch (saveError) {
      toast(saveError.message || "Could not save budget.");
    }
  };

  const deleteBudget = async (budget) => {
    if (!window.confirm(`Delete the ${budget.category} budget?`)) return;

    try {
      await api.deleteBudget(budget.id);
      setBudgets((current) => current.filter((item) => item.id !== budget.id));
      toast("Budget deleted");
    } catch (deleteError) {
      toast(deleteError.message || "Could not delete budget.");
    }
  };

  const monthLabel = new Date(
    `${selectedMonth}-02T12:00:00`,
  ).toLocaleDateString("en-IN", { month: "long", year: "numeric" });

  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">
            <span className="live-dot" /> PLAN YOUR SPENDING
          </div>
          <h1>Budgets</h1>
          <p>Set a monthly limit for each category and track your spending.</p>
        </div>
        <div className="budget-heading-actions">
          <label className="budget-month-picker">
            <span>Month</span>
            <input
              type="month"
              value={selectedMonth}
              onChange={(event) => setSelectedMonth(event.target.value)}
            />
          </label>
          <button
            className="primary-button"
            onClick={() => openModal()}
            disabled={!availableCategories.length}
          >
            <span>＋</span> Add budget
          </button>
        </div>
      </div>

      <section className="summary-grid budget-summary-grid">
        <div className="summary-card">
          <span className="card-label">MONTHLY LIMITS</span>
          <div className="metric-value">{formatMoney(totals.limit)}</div>
          <div className="metric-caption">Total planned for {monthLabel}</div>
        </div>
        <div className="summary-card">
          <span className="card-label">SPENT SO FAR</span>
          <div className="metric-value">{formatMoney(totals.spent)}</div>
          <div className="metric-caption">Across categories with a budget</div>
        </div>
      </section>

      {error && (
        <div className="api-alert">
          <span>!</span>
          <div>
            <b>Could not load budgets</b>
            <small>{error}</small>
          </div>
          <button onClick={loadBudgets}>Try again</button>
        </div>
      )}

      {!loading && budgetAlerts.length > 0 && (
        <section className="budget-alert-list" aria-label="Budget alerts">
          <div className="budget-alert-heading">
            <span>!</span>
            <div>
              <b>Budget alerts</b>
              <small>These categories are close to or over their monthly limits.</small>
            </div>
          </div>
          <div className="budget-alert-items">
            {budgetAlerts.map((budget) => {
              const over = Number(budget.percentage) >= 100;
              return (
                <div className={`budget-alert-item ${over ? "over" : "near"}`} key={budget.id}>
                  <b>{budget.category}</b>
                  <span>
                    {over
                      ? `${Math.round(Number(budget.percentage))}% used · ${formatMoney(Number(budget.spent) - Number(budget.amount))} over`
                      : `${Math.round(Number(budget.percentage))}% used · ${formatMoney(budget.remaining)} left`}
                  </span>
                </div>
              );
            })}
          </div>
        </section>
      )}

      <section className="budget-list">
        {loading ? (
          <div className="panel inline-state">Loading budgets…</div>
        ) : budgets.length ? (
          budgets.map((budget) => {
            const overBudget = Number(budget.spent) > Number(budget.amount);
            const progress = Math.min(Number(budget.percentage) || 0, 100);

            return (
              <article className="panel budget-card" key={budget.id}>
                <div className="budget-card-top">
                  <div className="budget-category-icon">▦</div>
                  <div className="budget-card-title">
                    <h2>{budget.category}</h2>
                    <p>{monthLabel}</p>
                  </div>
                  <div className="budget-card-actions">
                    <button
                      className="secondary-button"
                      onClick={() => openModal(budget)}
                    >
                      Edit
                    </button>
                    <button
                      className="secondary-button danger-button"
                      onClick={() => deleteBudget(budget)}
                    >
                      Delete
                    </button>
                  </div>
                </div>
                <div className="budget-card-amounts">
                  <strong>{formatMoney(budget.spent)}</strong>
                  <span>of {formatMoney(budget.amount)}</span>
                  <b className={overBudget ? "over-budget" : ""}>
                    {Math.round(Number(budget.percentage) || 0)}%
                  </b>
                </div>
                <div className="budget-progress-track">
                  <span
                    className={overBudget ? "over-budget" : ""}
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <p
                  className={`budget-remaining ${overBudget ? "over-budget" : ""}`}
                >
                  {overBudget
                    ? `${formatMoney(Number(budget.spent) - Number(budget.amount))} over budget`
                    : `${formatMoney(budget.remaining)} remaining`}
                </p>
              </article>
            );
          })
        ) : (
          <div className="panel empty-state budget-empty-state">
            <span>▦</span>
            <b>No budgets set for {monthLabel}</b>
            <p>Choose a category and set a spending limit for this month.</p>
            {!categories.length && (
              <p>Create a category first to add a budget.</p>
            )}
            {categories.length > 0 && (
              <button className="primary-button" onClick={() => openModal()}>
                ＋ Add your first budget
              </button>
            )}
          </div>
        )}
      </section>

      {modalOpen && (
        <div
          className="modal-backdrop"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setModalOpen(false);
          }}
        >
          <form className="modal" onSubmit={saveBudget}>
            <div className="modal-head">
              <div>
                <div className="eyebrow">MONTHLY SPENDING PLAN</div>
                <h2>{editingBudget ? "Edit budget" : "Add budget"}</h2>
              </div>
              <button
                type="button"
                className="close-button"
                onClick={() => setModalOpen(false)}
              >
                ×
              </button>
            </div>
            <label>
              Category
              <select
                required
                value={form.category}
                onChange={(event) =>
                  setForm({ ...form, category: event.target.value })
                }
              >
                {availableCategories.map((category) => (
                  <option key={category.id} value={category.name}>
                    {category.name}
                  </option>
                ))}
              </select>
            </label>
            <div className="budget-month-note">Budget month: {monthLabel}</div>
            <label>
              Monthly limit
              <input
                required
                min="1"
                type="number"
                step="0.01"
                placeholder="₹ 0"
                value={form.amount}
                onChange={(event) =>
                  setForm({ ...form, amount: event.target.value })
                }
              />
            </label>
            <div className="modal-actions">
              <button
                type="button"
                className="secondary-button"
                onClick={() => setModalOpen(false)}
              >
                Cancel
              </button>
              <button className="primary-button" type="submit">
                {editingBudget ? "Save changes" : "Save budget"} <span>→</span>
              </button>
            </div>
          </form>
        </div>
      )}
    </>
  );
}

export default BudgetsPage;
