import { useState } from "react";
import { api } from "./api";

function AuthPage({ onAuthenticated }) {
  const resetParams = new URLSearchParams(window.location.search);
  const initialToken = resetParams.get("token") || "";
  const [mode, setMode] = useState(initialToken ? "reset" : "login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState(resetParams.get("email") || "");
  const [password, setPassword] = useState("");
  const [passwordConfirmation, setPasswordConfirmation] = useState("");
  const [resetToken] = useState(initialToken);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const isRegister = mode === "register";
  const isForgot = mode === "forgot";
  const isReset = mode === "reset";

  const changeMode = (nextMode) => {
    setError("");
    setMessage("");
    setMode(nextMode);
  };

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    setMessage("");
    setSubmitting(true);

    try {
      if (isRegister) {
        const response = await api.register({
          name: name.trim(),
          email: email.trim(),
          password,
          password_confirmation: passwordConfirmation,
        });
        onAuthenticated(response);
      } else if (isForgot) {
        const response = await api.requestPasswordReset({ email: email.trim() });
        setMessage(response.message);
      } else if (isReset) {
        const response = await api.resetPassword({
          email: email.trim(),
          token: resetToken,
          password,
          password_confirmation: passwordConfirmation,
        });
        window.history.replaceState({}, "", window.location.pathname);
        setPassword("");
        setPasswordConfirmation("");
        changeMode("login");
        setMessage(response.message);
      } else {
        const response = await api.login({ email: email.trim(), password });
        onAuthenticated(response);
      }
    } catch (requestError) {
      setError(requestError.message || "Could not connect to the Laravel API.");
    } finally {
      setSubmitting(false);
    }
  };

  const title = isRegister
    ? "Create your account"
    : isForgot
      ? "Forgot your password?"
      : isReset
        ? "Choose a new password"
        : "Welcome back";

  return (
    <main className="auth-screen">
      <section className="auth-card">
        <a className="brand auth-brand" href="#home">
          <span className="brand-mark">k</span>
          <span>
            kharcha<span className="brand-dot">.</span>
          </span>
        </a>
        <div className="auth-eyebrow">
          <span className="live-dot" /> PERSONAL FINANCE, MADE CLEAR
        </div>
        <h1>{title}</h1>
        <p className="auth-description">
          {isRegister
            ? "Create an account to keep your finances private and organized."
            : isForgot
              ? "Enter your email and we’ll send a password reset link if an account exists."
              : isReset
                ? "Choose a new password for your Kharcha account."
                : "Sign in to see your personal finance dashboard."}
        </p>

        {error && (
          <div className="auth-error" role="alert">
            {error}
          </div>
        )}
        {message && (
          <div className="auth-message" role="status">
            {message}
          </div>
        )}

        <form className="auth-form" onSubmit={submit}>
          {isRegister && (
            <label>
              Full name
              <input
                required
                maxLength="100"
                autoComplete="name"
                placeholder="Your name"
                value={name}
                onChange={(event) => setName(event.target.value)}
              />
            </label>
          )}
          <label>
            Email address
            <input
              required
              type="email"
              autoComplete="email"
              placeholder="you@example.com"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
            />
          </label>
          {!isForgot && (
            <label>
              {isReset ? "New password" : "Password"}
              <input
                required
                minLength="8"
                type={showPassword ? "text" : "password"}
                autoComplete={isRegister || isReset ? "new-password" : "current-password"}
                placeholder="At least 8 characters"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
              />
            </label>
          )}
          {(isRegister || isReset) && (
            <label>
              Confirm password
              <input
                required
                minLength="8"
                type={showPassword ? "text" : "password"}
                autoComplete="new-password"
                placeholder="Enter your password again"
                value={passwordConfirmation}
                onChange={(event) => setPasswordConfirmation(event.target.value)}
              />
            </label>
          )}
          {!isForgot && (
            <label className="auth-show-password">
              <input
                type="checkbox"
                checked={showPassword}
                onChange={(event) => setShowPassword(event.target.checked)}
              />
              Show password
            </label>
          )}
          {!isRegister && !isForgot && !isReset && (
            <button
              type="button"
              className="auth-forgot-link"
              onClick={() => changeMode("forgot")}
            >
              Forgot password?
            </button>
          )}
          <button className="primary-button auth-submit" disabled={submitting}>
            {submitting
              ? "Please wait…"
              : isRegister
                ? "Create account"
                : isForgot
                  ? "Send reset link"
                  : isReset
                    ? "Save new password"
                    : "Sign in"}
            {!submitting && <span>→</span>}
          </button>
        </form>

        <div className="auth-switch">
          {isRegister ? (
            <>
              Already have an account?{" "}
              <button type="button" onClick={() => changeMode("login")}>Sign in</button>
            </>
          ) : isForgot || isReset ? (
            <>
              Remembered your password?{" "}
              <button type="button" onClick={() => changeMode("login")}>Sign in</button>
            </>
          ) : (
            <>
              New to Kharcha?{" "}
              <button type="button" onClick={() => changeMode("register")}>Create an account</button>
            </>
          )}
        </div>
        {(isForgot || isReset) && (
          <p className="auth-mail-note">
            Password reset email delivery needs mail settings in the Laravel backend.
          </p>
        )}
      </section>
    </main>
  );
}

export default AuthPage;
