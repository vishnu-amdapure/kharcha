import { useEffect, useState } from "react";
import { api } from "./api";

const currentMonth = () => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
};

const money = (amount) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(Number(amount || 0));

export default function MonthlyReportPage() {
  const [month, setMonth] = useState(currentMonth());
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadReport = async () => {
    setLoading(true);
    setError("");
    try {
      setReport(await api.getMonthlyReport(month));
    } catch (loadError) {
      setError(loadError.message || "Could not load this monthly report.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReport();
  }, [month]);

  const monthLabel = new Date(`${month}-02T12:00:00`).toLocaleDateString("en-IN", {
    month: "long",
    year: "numeric",
  });
  const maxCategory = Math.max(1, ...(report?.category_spending || []).map((item) => Number(item.amount)));
  const maxDaily = Math.max(
    1,
    ...(report?.daily_activity || []).flatMap((item) => [Number(item.income), Number(item.expenses)]),
  );

  const downloadReportCsv = () => {
    if (!report) return;
    const escape = (value) => `"${String(value ?? "").replaceAll('"', '""')}"`;
    const rows = [
      ["Kharcha monthly report", monthLabel],
      ["Income", report.income],
      ["Expenses", report.expenses],
      ["Net balance", report.balance],
      ["Transactions", report.transaction_count],
      [],
      ["Spending by category"],
      ["Category", "Amount"],
      ...report.category_spending.map((item) => [item.name, item.amount]),
      [],
      ["Daily money flow"],
      ["Date", "Income", "Expenses"],
      ...report.daily_activity.map((item) => [item.date, item.income, item.expenses]),
      [],
      ["Latest transactions"],
      ["Date", "Description", "Category", "Type", "Amount"],
      ...report.transactions.map((item) => [item.date, item.description, item.category, item.type, item.amount]),
    ];
    const blob = new Blob([`\uFEFF${rows.map((row) => row.map(escape).join(",")).join("\r\n")}`], {
      type: "text/csv;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `kharcha-report-${month}.csv`;
    link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  return (
    <>
      <div className="page-heading report-heading">
        <div>
          <div className="eyebrow">
            <span className="live-dot" /> YOUR MONTH, CLEARLY
          </div>
          <h1>Monthly report</h1>
          <p>See where your money came from and where it went.</p>
        </div>
        <div className="report-heading-actions">
          <label className="report-month-picker">
            <span>Choose month</span>
            <input type="month" value={month} onChange={(event) => setMonth(event.target.value)} />
          </label>
          <div className="report-actions">
            <button className="secondary-button" onClick={downloadReportCsv} disabled={!report}>Download CSV</button>
            <button className="secondary-button" onClick={() => window.print()} disabled={!report}>Save as PDF</button>
          </div>
        </div>
      </div>

      {error && (
        <div className="api-alert">
          <span>!</span>
          <div><b>Report could not load</b><small>{error}</small></div>
          <button onClick={loadReport}>Try again</button>
        </div>
      )}

      {loading ? (
        <div className="panel inline-state">Preparing your {monthLabel} report…</div>
      ) : report ? (
        <>
          <section className="summary-grid report-summary-grid">
            <div className="summary-card">
              <span className="card-label">INCOME</span>
              <div className="metric-value">{money(report.income)}</div>
              <div className="metric-caption">Money received in {monthLabel}</div>
            </div>
            <div className="summary-card">
              <span className="card-label">EXPENSES</span>
              <div className="metric-value">{money(report.expenses)}</div>
              <div className="metric-caption">Money spent in {monthLabel}</div>
            </div>
            <div className="summary-card report-balance-card">
              <span className="card-label">NET BALANCE</span>
              <div className="metric-value">{money(report.balance)}</div>
              <div className="metric-caption">{report.transaction_count} transactions</div>
            </div>
          </section>

          <div className="report-content-grid">
            <section className="panel report-panel">
              <div className="panel-heading">
                <div><h2>Spending by category</h2><p>{monthLabel}</p></div>
              </div>
              {report.category_spending.length ? (
                <div className="report-category-list">
                  {report.category_spending.map((category) => (
                    <div className="report-category-row" key={category.name}>
                      <div className="report-category-top">
                        <b>{category.name}</b><span>{money(category.amount)}</span>
                      </div>
                      <div className="report-category-track">
                        <span style={{ width: `${(category.amount / maxCategory) * 100}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="report-empty">No expenses recorded for this month.</div>
              )}
            </section>

            <section className="panel report-panel report-daily-panel">
              <div className="panel-heading">
                <div><h2>Daily money flow</h2><p>Income and expenses by day</p></div>
              </div>
              {report.daily_activity.some((day) => day.income || day.expenses) ? (
                <>
                  <div className="report-daily-chart" aria-label={`Daily income and expenses for ${monthLabel}`}>
                    {report.daily_activity.map((day) => (
                      <div className="report-day" key={day.date} title={`${day.date}: income ${money(day.income)}, expenses ${money(day.expenses)}`}>
                        <div className="report-day-bars">
                          <i className="report-income-bar" style={{ height: `${Math.max(day.income ? 3 : 0, (day.income / maxDaily) * 100)}%` }} />
                          <i className="report-expense-bar" style={{ height: `${Math.max(day.expenses ? 3 : 0, (day.expenses / maxDaily) * 100)}%` }} />
                        </div>
                        {(new Date(`${day.date}T12:00:00`).getDate() === 1 || new Date(`${day.date}T12:00:00`).getDate() % 5 === 0) && (
                          <small>{new Date(`${day.date}T12:00:00`).getDate()}</small>
                        )}
                      </div>
                    ))}
                  </div>
                  <div className="chart-legend">
                    <span><i className="legend-income" /> Income</span>
                    <span><i className="legend-expense" /> Expenses</span>
                  </div>
                </>
              ) : (
                <div className="report-empty">Daily activity will show here when you add transactions.</div>
              )}
            </section>
          </div>

          <section className="panel report-transactions-panel">
            <div className="panel-heading">
              <div><h2>Recent transactions</h2><p>Latest 12 transactions from {monthLabel}</p></div>
            </div>
            {report.transactions.length ? (
              <div className="report-transaction-list">
                {report.transactions.map((transaction) => (
                  <div className="report-transaction-row" key={transaction.id}>
                    <div><b>{transaction.description}</b><small>{transaction.category} · {transaction.date}</small></div>
                    <strong className={transaction.type === "income" ? "report-income" : "report-expense"}>
                      {transaction.type === "income" ? "+" : "−"}{money(transaction.amount)}
                    </strong>
                  </div>
                ))}
              </div>
            ) : (
              <div className="report-empty">No transactions recorded for this month.</div>
            )}
          </section>
        </>
      ) : null}
    </>
  );
}
