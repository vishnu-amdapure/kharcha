# Kharcha — React frontend

React + Vite frontend for a personal expense tracker. Mock data is disabled. The app expects a Laravel API at `http://127.0.0.1:8000/api` by default.

## Run the frontend

```bash
npm install
npm run dev
```

If your Laravel API runs at another address, copy `.env.example` to `.env` and update `VITE_API_URL`, then restart Vite.

## First API to connect

The dashboard currently calls `GET /transactions` on load. It accepts either a plain array or Laravel's `{ "data": [...] }` resource response. Each transaction should include `id`, `amount`, `type` (`income` or `expense`), `date`, and either `description` or `name`; a `category` can be a string or `{ "name": "..." }`.

Add the endpoints incrementally in `src/api.js`:

- `GET /transactions` — loaded by the dashboard and transactions page
- `POST /transactions` — add a transaction
- `DELETE /transactions/{id}` — remove a transaction
- `GET /categories` — categories page
- `GET /dashboard/summary` — category totals and cash flow charts

For protected endpoints, save the Laravel bearer token as `kharcha_token` in `localStorage`; the API helper automatically sends it. Register/login screens and token handling can be added when the Laravel auth API is ready.
