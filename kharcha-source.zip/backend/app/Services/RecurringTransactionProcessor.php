<?php

namespace App\Services;

use App\Models\RecurringTransaction;
use App\Models\User;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\DB;

class RecurringTransactionProcessor
{
    /** @return array<int, mixed> */
    public function processForUser(User $user): array
    {
        $today = CarbonImmutable::today();
        $created = [];

        $dueIds = $user->recurringTransactions()
            ->where('active', true)
            ->whereDate('next_due_date', '<=', $today->toDateString())
            ->pluck('id');

        foreach ($dueIds as $id) {
            DB::transaction(function () use ($id, $user, $today, &$created): void {
                $schedule = RecurringTransaction::query()
                    ->where('user_id', $user->id)
                    ->lockForUpdate()
                    ->find($id);

                if (!$schedule || !$schedule->active) {
                    return;
                }

                $dueDate = CarbonImmutable::parse($schedule->next_due_date);
                $endDate = $schedule->end_date
                    ? CarbonImmutable::parse($schedule->end_date)
                    : null;
                $occurrences = 0;

                while (
                    $dueDate->lessThanOrEqualTo($today)
                    && (!$endDate || $dueDate->lessThanOrEqualTo($endDate))
                    && $occurrences < 500
                ) {
                    $created[] = $user->transactions()->create([
                        'description' => $schedule->description,
                        'category' => $schedule->category,
                        'amount' => $schedule->amount,
                        'type' => $schedule->type,
                        'date' => $dueDate->toDateString(),
                    ]);

                    $dueDate = $this->nextOccurrence($schedule, $dueDate);
                    $occurrences++;
                }

                $schedule->next_due_date = $dueDate->toDateString();
                if ($endDate && $dueDate->greaterThan($endDate)) {
                    $schedule->active = false;
                }
                $schedule->save();
            });
        }

        return $created;
    }

    private function nextOccurrence(RecurringTransaction $schedule, CarbonImmutable $date): CarbonImmutable
    {
        if ($schedule->frequency === 'weekly') {
            return $date->addWeek();
        }

        $nextMonth = $date->addMonthNoOverflow();
        $day = min((int) $schedule->day_of_month, $nextMonth->daysInMonth);

        return $nextMonth->day($day);
    }
}
