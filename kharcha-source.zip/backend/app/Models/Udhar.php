<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Udhar extends Model
{
    protected $fillable = [
        'user_id',
        'person_name',
        'direction',
        'amount',
        'date',
        'due_date',
        'note',
    ];

    protected function casts(): array
    {
        return [
            'amount' => 'decimal:2',
            'date' => 'date:Y-m-d',
            'due_date' => 'date:Y-m-d',
        ];
    }

    public function payments(): HasMany
    {
        return $this->hasMany(UdharPayment::class);
    }
}
