<?php

namespace App\Console\Commands;

use App\Models\User;
use App\Services\RecurringTransactionProcessor;
use Illuminate\Console\Command;

class ProcessDueRecurringTransactions extends Command
{
    protected $signature = 'recurring:process-due';

    protected $description = 'Create transactions for all due recurring schedules';

    public function handle(RecurringTransactionProcessor $processor): int
    {
        $createdCount = 0;

        User::query()
            ->whereHas('recurringTransactions', function ($query): void {
                $query->where('active', true)
                    ->whereDate('next_due_date', '<=', now()->toDateString());
            })
            ->chunkById(100, function ($users) use ($processor, &$createdCount): void {
                foreach ($users as $user) {
                    $createdCount += count($processor->processForUser($user));
                }
            });

        $this->info("Created {$createdCount} recurring transaction(s).");

        return self::SUCCESS;
    }
}
