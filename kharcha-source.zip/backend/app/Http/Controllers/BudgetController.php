<?php

namespace App\Http\Controllers;

use App\Models\Budget;
use App\Models\Transaction;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class BudgetController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'month' => ['sometimes', 'date_format:Y-m'],
        ]);
        $month = isset($validated['month'])
            ? Carbon::createFromFormat('Y-m', $validated['month'])->startOfMonth()
            : Carbon::now()->startOfMonth();
        $userId = $request->user()->id;
        $spending = Transaction::query()
            ->where('user_id', $userId)
            ->where('type', 'expense')
            ->whereBetween('date', [
                $month->toDateString(),
                $month->copy()->endOfMonth()->toDateString(),
            ])
            ->selectRaw('category, SUM(amount) as total')
            ->groupBy('category')
            ->pluck('total', 'category');

        $budgets = $request->user()->budgets()
            ->whereDate('month', $month->toDateString())
            ->orderBy('category')
            ->get()
            ->map(fn (Budget $budget) => $this->withSpending(
                $budget,
                (float) ($spending[$budget->category] ?? 0),
            ));

        return response()->json($budgets);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $this->validatedData($request);
        $validated['month'] = Carbon::createFromFormat('Y-m', $validated['month'])
            ->startOfMonth()
            ->toDateString();

        $budget = $request->user()->budgets()->create($validated);

        return response()->json($this->withSpending($budget, $this->spentFor($budget)), 201);
    }

    public function show(Request $request, Budget $budget): JsonResponse
    {
        $budget = $request->user()->budgets()->findOrFail($budget->id);
        return response()->json($this->withSpending($budget, $this->spentFor($budget)));
    }

    public function update(Request $request, Budget $budget): JsonResponse
    {
        $budget = $request->user()->budgets()->findOrFail($budget->id);
        $validated = $this->validatedData($request, $budget);
        $validated['month'] = Carbon::createFromFormat('Y-m', $validated['month'])
            ->startOfMonth()
            ->toDateString();
        $budget->update($validated);

        return response()->json($this->withSpending($budget->fresh(), $this->spentFor($budget)));
    }

    public function destroy(Request $request, Budget $budget): JsonResponse
    {
        $request->user()->budgets()->findOrFail($budget->id)->delete();

        return response()->json(null, 204);
    }

    private function validatedData(Request $request, ?Budget $budget = null): array
    {
        $categoryRule = Rule::unique('budgets', 'category')
            ->where('user_id', $request->user()->id)
            ->where('month', $request->input('month').'-01');

        if ($budget) {
            $categoryRule->ignoreModel($budget);
        }

        return $request->validate([
            'category' => [
                'required',
                'string',
                'max:100',
                Rule::exists('categories', 'name')->where('user_id', $request->user()->id),
                $categoryRule,
            ],
            'month' => ['required', 'date_format:Y-m'],
            'amount' => ['required', 'numeric', 'min:0.01'],
        ]);
    }

    private function spentFor(Budget $budget): float
    {
        $month = Carbon::parse($budget->month);

        return (float) Transaction::query()
            ->where('user_id', $budget->user_id)
            ->where('type', 'expense')
            ->where('category', $budget->category)
            ->whereBetween('date', [
                $month->toDateString(),
                $month->copy()->endOfMonth()->toDateString(),
            ])
            ->sum('amount');
    }

    private function withSpending(Budget $budget, float $spent): array
    {
        $limit = (float) $budget->amount;

        return [
            'id' => $budget->id,
            'category' => $budget->category,
            'month' => Carbon::parse($budget->month)->format('Y-m'),
            'amount' => $limit,
            'spent' => $spent,
            'remaining' => max(0, $limit - $spent),
            'percentage' => $limit > 0 ? round(($spent / $limit) * 100, 1) : 0,
        ];
    }
}
