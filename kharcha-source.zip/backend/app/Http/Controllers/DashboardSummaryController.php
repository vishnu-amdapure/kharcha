<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class DashboardSummaryController extends Controller
{
    public function show(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'period' => [
                'sometimes',
                Rule::in(['this_month', 'last_month', 'this_year', 'all_time']),
            ],
        ]);
        $period = $validated['period'] ?? 'this_month';
        $userId = $request->user()->id;

        $income = (float) Transaction::query()
            ->where('user_id', $userId)
            ->where('type', 'income')
            ->sum('amount');

        $expenses = (float) Transaction::query()
            ->where('user_id', $userId)
            ->where('type', 'expense')
            ->sum('amount');

        $now = Carbon::now();
        [$periodStart, $periodEnd] = match ($period) {
            'last_month' => [
                $now->copy()->subMonthNoOverflow()->startOfMonth(),
                $now->copy()->subMonthNoOverflow()->endOfMonth(),
            ],
            'this_year' => [$now->copy()->startOfYear(), $now->copy()->endOfYear()],
            'all_time' => [null, null],
            default => [$now->copy()->startOfMonth(), $now->copy()->endOfMonth()],
        };

        $categoryQuery = Transaction::query()
            ->where('user_id', $userId)
            ->where('type', 'expense');
        if ($periodStart && $periodEnd) {
            $categoryQuery->whereBetween('date', [
                $periodStart->toDateString(),
                $periodEnd->toDateString(),
            ]);
        }

        $categorySpending = $categoryQuery
            ->selectRaw('category, SUM(amount) as amount')
            ->groupBy('category')
            ->orderByDesc('amount')
            ->get()
            ->map(fn ($row) => [
                'name' => $row->category,
                'amount' => (float) $row->amount,
            ])
            ->values();

        $firstMonth = Carbon::now()->startOfMonth()->subMonths(5);
        $lastMonth = Carbon::now()->endOfMonth();
        $cashFlowTotals = [];

        Transaction::query()
            ->where('user_id', $userId)
            ->whereBetween('date', [
                $firstMonth->toDateString(),
                $lastMonth->toDateString(),
            ])
            ->get(['date', 'type', 'amount'])
            ->each(function (Transaction $transaction) use (&$cashFlowTotals) {
                $monthKey = Carbon::parse($transaction->date)->format('Y-m');
                $cashFlowTotals[$monthKey][$transaction->type] =
                    ($cashFlowTotals[$monthKey][$transaction->type] ?? 0)
                    + (float) $transaction->amount;
            });

        $cashFlow = collect(range(0, 5))
            ->map(function (int $offset) use ($firstMonth, $cashFlowTotals) {
                $month = $firstMonth->copy()->addMonths($offset);
                $key = $month->format('Y-m');

                return [
                    'key' => $key,
                    'label' => $month->format('M'),
                    'income' => round($cashFlowTotals[$key]['income'] ?? 0, 2),
                    'expenses' => round($cashFlowTotals[$key]['expense'] ?? 0, 2),
                ];
            });

        return response()->json([
            'period' => $period,
            'income' => round($income, 2),
            'expenses' => round($expenses, 2),
            'balance' => round($income - $expenses, 2),
            'category_spending' => $categorySpending,
            'cash_flow' => $cashFlow,
        ]);
    }
}
