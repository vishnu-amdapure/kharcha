<?php

namespace App\Http\Controllers;

use App\Models\Udhar;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class UdharController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $entries = $request->user()->udhars()
            ->with('payments')
            ->withSum('payments as paid_amount', 'amount')
            ->orderByDesc('date')
            ->orderByDesc('id')
            ->get();

        return response()->json($entries->map(fn (Udhar $entry) => $this->formatEntry($entry)));
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'person_name' => ['required', 'string', 'max:150'],
            'direction' => ['required', 'in:given,taken'],
            'amount' => ['required', 'numeric', 'min:0.01'],
            'date' => ['required', 'date'],
            'due_date' => ['nullable', 'date', 'after_or_equal:date'],
            'note' => ['nullable', 'string', 'max:1000'],
        ]);

        $entry = $request->user()->udhars()->create($validated)
            ->load('payments')
            ->loadSum('payments', 'amount');

        return response()->json($this->formatEntry($entry), 201);
    }

    public function show(Request $request, Udhar $udhar): JsonResponse
    {
        $udhar = $request->user()->udhars()->findOrFail($udhar->id);
        $entry = $udhar->load('payments')->loadSum('payments', 'amount');

        return response()->json($this->formatEntry($entry));
    }

    public function update(Request $request, Udhar $udhar): JsonResponse
    {
        $udhar = $request->user()->udhars()->findOrFail($udhar->id);
        $validated = $request->validate([
            'person_name' => ['sometimes', 'required', 'string', 'max:150'],
            'direction' => ['sometimes', 'required', 'in:given,taken'],
            'amount' => ['sometimes', 'required', 'numeric', 'min:0.01'],
            'date' => ['sometimes', 'required', 'date'],
            'due_date' => ['sometimes', 'nullable', 'date'],
            'note' => ['sometimes', 'nullable', 'string', 'max:1000'],
        ]);

        if (isset($validated['amount'])) {
            $alreadyPaid = (float) $udhar->payments()->sum('amount');

            if ((float) $validated['amount'] < $alreadyPaid) {
                throw ValidationException::withMessages([
                    'amount' => ['The amount cannot be less than the repayments already recorded.'],
                ]);
            }
        }

        $udhar->update($validated);
        $entry = $udhar->fresh()->load('payments')->loadSum('payments', 'amount');

        return response()->json($this->formatEntry($entry));
    }

    public function destroy(Request $request, Udhar $udhar): JsonResponse
    {
        $request->user()->udhars()->findOrFail($udhar->id)->delete();

        return response()->json(null, 204);
    }

    public function storePayment(Request $request, Udhar $udhar): JsonResponse
    {
        $udhar = $request->user()->udhars()->findOrFail($udhar->id);
        $validated = $request->validate([
            'amount' => ['required', 'numeric', 'min:0.01'],
            'date' => ['required', 'date'],
            'note' => ['nullable', 'string', 'max:500'],
        ]);

        $alreadyPaid = (float) $udhar->payments()->sum('amount');
        $remaining = (float) $udhar->amount - $alreadyPaid;

        if ((float) $validated['amount'] > $remaining) {
            throw ValidationException::withMessages([
                'amount' => ['The payment cannot be greater than the remaining balance.'],
            ]);
        }

        $udhar->payments()->create($validated);
        $entry = $udhar->fresh()->load('payments')->loadSum('payments', 'amount');

        return response()->json($this->formatEntry($entry));
    }

    private function formatEntry(Udhar $entry): array
    {
        $data = $entry->toArray();
        $paidAmount = (float) ($entry->paid_amount ?? $entry->payments_sum_amount ?? 0);
        $remainingAmount = max(0, (float) $entry->amount - $paidAmount);

        unset($data['payments_sum_amount']);
        $data['paid_amount'] = $paidAmount;
        $data['remaining_amount'] = $remainingAmount;
        $data['status'] = $remainingAmount <= 0.0 ? 'settled' : 'open';

        return $data;
    }
}
