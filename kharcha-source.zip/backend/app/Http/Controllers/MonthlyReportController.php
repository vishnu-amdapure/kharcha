<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MonthlyReportController extends Controller
{
    public function show(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'month' => ['sometimes', 'date_format:Y-m'],
        ]);
        $month = Carbon::createFromFormat('Y-m', $validated['month'] ?? now()->format('Y-m'))
            ->startOfMonth();
        $transactions = $request->user()->transactions()
            ->whereBetween('date', [
                $month->toDateString(),
                $month->copy()->endOfMonth()->toDateString(),
            ])
            ->orderByDesc('date')
            ->orderByDesc('id')
            ->get(['id', 'description', 'category', 'amount', 'type', 'date']);

        $income = (float) $transactions->where('type', 'income')->sum('amount');
        $expenses = (float) $transactions->where('type', 'expense')->sum('amount');
        $categorySpending = $transactions
            ->where('type', 'expense')
            ->groupBy('category')
            ->map(fn ($items, $category) => [
                'name' => $category,
                'amount' => round((float) $items->sum('amount'), 2),
            ])
            ->sortByDesc('amount')
            ->values();

        $dailyTotals = $transactions->groupBy(fn ($transaction) =>
            Carbon::parse($transaction->date)->format('Y-m-d')
        );
        $dailyActivity = collect(range(1, $month->daysInMonth))
            ->map(function (int $day) use ($month, $dailyTotals) {
                $date = $month->copy()->day($day)->format('Y-m-d');
                $items = $dailyTotals->get($date, collect());

                return [
                    'date' => $date,
                    'income' => round((float) $items->where('type', 'income')->sum('amount'), 2),
                    'expenses' => round((float) $items->where('type', 'expense')->sum('amount'), 2),
                ];
            });

        return response()->json([
            'month' => $month->format('Y-m'),
            'income' => round($income, 2),
            'expenses' => round($expenses, 2),
            'balance' => round($income - $expenses, 2),
            'transaction_count' => $transactions->count(),
            'category_spending' => $categorySpending,
            'daily_activity' => $dailyActivity,
            'transactions' => $transactions->take(12)->values(),
        ]);
    }
}
