<?php

namespace App\Http\Controllers;

use App\Models\RecurringTransaction;
use App\Services\RecurringTransactionProcessor;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class RecurringTransactionController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $schedules = $request->user()->recurringTransactions()
            ->orderByDesc('active')
            ->orderBy('next_due_date')
            ->get();

        return response()->json($schedules);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'description' => ['required', 'string', 'max:255'],
            'category' => ['required', 'string', 'max:100'],
            'amount' => ['required', 'numeric', 'min:0.01'],
            'type' => ['required', 'in:income,expense'],
            'frequency' => ['required', 'in:weekly,monthly'],
            'start_date' => ['required', 'date'],
            'end_date' => ['nullable', 'date', 'after_or_equal:start_date'],
        ]);

        $validated['next_due_date'] = $validated['start_date'];
        $validated['day_of_month'] = $validated['frequency'] === 'monthly'
            ? (int) CarbonImmutable::parse($validated['start_date'])->day
            : null;

        $schedule = $request->user()->recurringTransactions()->create($validated);

        return response()->json($schedule, 201);
    }

    public function update(Request $request, RecurringTransaction $recurringTransaction): JsonResponse
    {
        $validated = $request->validate([
            'active' => ['required', 'boolean'],
        ]);

        $schedule = $request->user()->recurringTransactions()
            ->findOrFail($recurringTransaction->id);
        $schedule->update($validated);

        return response()->json($schedule->fresh());
    }

    public function destroy(Request $request, RecurringTransaction $recurringTransaction): JsonResponse
    {
        $request->user()->recurringTransactions()
            ->findOrFail($recurringTransaction->id)
            ->delete();

        return response()->json(null, 204);
    }

    public function processDue(Request $request, RecurringTransactionProcessor $processor): JsonResponse
    {
        $created = $processor->processForUser($request->user());

        return response()->json([
            'created_count' => count($created),
            'transactions' => $created,
        ]);
    }

}
