<?php

namespace App\Http\Controllers;

use App\Models\SavingsGoal;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SavingsGoalController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $goals = $request->user()->savingsGoals()
            ->orderByRaw('target_date IS NULL')
            ->orderBy('target_date')
            ->orderBy('name')
            ->get()
            ->map(fn (SavingsGoal $goal) => $this->goalData($goal));

        return response()->json($goals);
    }

    public function store(Request $request): JsonResponse
    {
        $goal = $request->user()->savingsGoals()->create($this->validatedData($request));

        return response()->json($this->goalData($goal), 201);
    }

    public function update(Request $request, int $savings_goal): JsonResponse
    {
        $goal = $request->user()->savingsGoals()->findOrFail($savings_goal);
        $goal->update($this->validatedData($request));

        return response()->json($this->goalData($goal->fresh()));
    }

    public function destroy(Request $request, int $savings_goal): JsonResponse
    {
        $request->user()->savingsGoals()->findOrFail($savings_goal)->delete();

        return response()->json(null, 204);
    }

    private function validatedData(Request $request): array
    {
        return $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'target_amount' => ['required', 'numeric', 'min:0.01', 'max:9999999999.99'],
            'saved_amount' => ['required', 'numeric', 'min:0', 'lte:target_amount'],
            'target_date' => ['nullable', 'date_format:Y-m-d'],
        ]);
    }

    private function goalData(SavingsGoal $goal): array
    {
        $target = (float) $goal->target_amount;
        $saved = (float) $goal->saved_amount;

        return [
            'id' => $goal->id,
            'name' => $goal->name,
            'target_amount' => $target,
            'saved_amount' => $saved,
            'remaining_amount' => max(0, $target - $saved),
            'percentage' => $target > 0 ? round(($saved / $target) * 100, 1) : 0,
            'target_date' => $goal->target_date?->format('Y-m-d'),
        ];
    }
}
