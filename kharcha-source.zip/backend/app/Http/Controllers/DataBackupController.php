<?php

namespace App\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DataBackupController extends Controller
{
    public function show(Request $request): JsonResponse
    {
        $user = $request->user();

        return response()->json([
            'format' => 'kharcha-backup-v1',
            'exported_at' => now()->toIso8601String(),
            'profile' => [
                'name' => $user->name,
                'email' => $user->email,
            ],
            'categories' => $user->categories()->orderBy('name')->get(),
            'transactions' => $user->transactions()->orderBy('date')->get(),
            'budgets' => $user->budgets()->orderBy('month')->get(),
            'lending' => $user->udhars()->with('payments')->orderBy('date')->get(),
            'recurring_transactions' => $user->recurringTransactions()
                ->orderBy('created_at')->get(),
        ]);
    }

    public function restore(Request $request): JsonResponse
    {
        $backup = $request->validate([
            'format' => ['required', 'in:kharcha-backup-v1'],
            'categories' => ['required', 'array', 'max:500'],
            'categories.*.name' => ['required', 'string', 'max:100'],
            'transactions' => ['required', 'array', 'max:10000'],
            'transactions.*.description' => ['required', 'string', 'max:255'],
            'transactions.*.category' => ['required', 'string', 'max:100'],
            'transactions.*.amount' => ['required', 'numeric', 'min:0.01'],
            'transactions.*.type' => ['required', 'in:income,expense'],
            'transactions.*.date' => ['required', 'date'],
            'budgets' => ['required', 'array', 'max:5000'],
            'budgets.*.category' => ['required', 'string', 'max:100'],
            'budgets.*.month' => ['required', 'date'],
            'budgets.*.amount' => ['required', 'numeric', 'min:0.01'],
            'lending' => ['required', 'array', 'max:5000'],
            'lending.*.person_name' => ['required', 'string', 'max:150'],
            'lending.*.direction' => ['required', 'in:given,taken'],
            'lending.*.amount' => ['required', 'numeric', 'min:0.01'],
            'lending.*.date' => ['required', 'date'],
            'lending.*.due_date' => ['nullable', 'date'],
            'lending.*.note' => ['nullable', 'string', 'max:1000'],
            'lending.*.payments' => ['sometimes', 'array', 'max:1000'],
            'lending.*.payments.*.amount' => ['required', 'numeric', 'min:0.01'],
            'lending.*.payments.*.date' => ['required', 'date'],
            'lending.*.payments.*.note' => ['nullable', 'string', 'max:500'],
            'recurring_transactions' => ['required', 'array', 'max:2000'],
            'recurring_transactions.*.description' => ['required', 'string', 'max:255'],
            'recurring_transactions.*.category' => ['required', 'string', 'max:100'],
            'recurring_transactions.*.amount' => ['required', 'numeric', 'min:0.01'],
            'recurring_transactions.*.type' => ['required', 'in:income,expense'],
            'recurring_transactions.*.frequency' => ['required', 'in:weekly,monthly'],
            'recurring_transactions.*.start_date' => ['required', 'date'],
            'recurring_transactions.*.next_due_date' => ['required', 'date'],
            'recurring_transactions.*.day_of_month' => ['nullable', 'integer', 'between:1,31'],
            'recurring_transactions.*.end_date' => ['nullable', 'date'],
            'recurring_transactions.*.active' => ['required', 'boolean'],
        ]);

        $user = $request->user();

        DB::transaction(function () use ($backup, $user): void {
            // Restore replaces only this signed-in user's data. IDs and user_id
            // values from the uploaded file are deliberately ignored.
            $user->transactions()->delete();
            $user->budgets()->delete();
            $user->recurringTransactions()->delete();
            $user->udhars()->delete();
            $user->categories()->delete();

            foreach ($backup['categories'] as $category) {
                $user->categories()->create(['name' => $category['name']]);
            }

            foreach ($backup['transactions'] as $transaction) {
                $user->transactions()->create(collect($transaction)->only([
                    'description', 'category', 'amount', 'type', 'date',
                ])->all());
            }

            foreach ($backup['budgets'] as $budget) {
                $user->budgets()->create(collect($budget)->only([
                    'category', 'month', 'amount',
                ])->all());
            }

            foreach ($backup['lending'] as $entry) {
                $payments = $entry['payments'] ?? [];
                $udhar = $user->udhars()->create(collect($entry)->only([
                    'person_name', 'direction', 'amount', 'date', 'due_date', 'note',
                ])->all());
                foreach ($payments as $payment) {
                    $udhar->payments()->create(collect($payment)->only([
                        'amount', 'date', 'note',
                    ])->all());
                }
            }

            foreach ($backup['recurring_transactions'] as $schedule) {
                $user->recurringTransactions()->create(collect($schedule)->only([
                    'description', 'category', 'amount', 'type', 'frequency',
                    'start_date', 'next_due_date', 'day_of_month', 'end_date', 'active',
                ])->all());
            }
        });

        return response()->json([
            'message' => 'Backup restored. This account now contains the records from that backup.',
        ]);
    }
}
