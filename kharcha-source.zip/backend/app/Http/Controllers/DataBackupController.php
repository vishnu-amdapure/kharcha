<?php

namespace App\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DataBackupController extends Controller
{
    public function show(Request $request): JsonResponse
    {
        $user = $request->user();

        return response()->json([
            'format' => 'kharcha-backup-v1',
            'exported_at' => now()->toIso8601String(),
            'profile' => [
                'name' => $user->name,
                'email' => $user->email,
            ],
            'categories' => $user->categories()->orderBy('name')->get(),
            'transactions' => $user->transactions()->orderBy('date')->get(),
            'budgets' => $user->budgets()->orderBy('month')->get(),
            'lending' => $user->udhars()->with('payments')->orderBy('date')->get(),
            'recurring_transactions' => $user->recurringTransactions()
                ->orderBy('created_at')->get(),
        ]);
    }
}
