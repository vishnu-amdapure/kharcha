<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class TransactionController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $filters = $request->validate([
            'type' => ['sometimes', 'in:income,expense'],
            'category' => ['sometimes', 'string', 'max:100'],
            'search' => ['sometimes', 'string', 'max:255'],
            'from' => ['sometimes', 'date'],
            'to' => ['sometimes', 'date'],
            'sort' => ['sometimes', 'in:newest,oldest,amount_high,amount_low'],
            'per_page' => ['sometimes', 'integer', 'min:1', 'max:100'],
            'page' => ['sometimes', 'integer', 'min:1'],
        ]);

        $transactions = $request->user()->transactions();

        if (!empty($filters['type'])) {
            $transactions->where('type', $filters['type']);
        }

        if (!empty($filters['category'])) {
            $transactions->where('category', $filters['category']);
        }

        if (!empty($filters['search'])) {
            $search = $filters['search'];
            $transactions->where(function ($query) use ($search) {
                $query->where('description', 'like', "%{$search}%")
                    ->orWhere('category', 'like', "%{$search}%");
            });
        }

        if (!empty($filters['from'])) {
            $transactions->whereDate('date', '>=', $filters['from']);
        }

        if (!empty($filters['to'])) {
            $transactions->whereDate('date', '<=', $filters['to']);
        }

        switch ($filters['sort'] ?? 'newest') {
            case 'oldest':
                $transactions->orderBy('date')->orderBy('id');
                break;
            case 'amount_high':
                $transactions->orderByDesc('amount')->orderByDesc('date');
                break;
            case 'amount_low':
                $transactions->orderBy('amount')->orderByDesc('date');
                break;
            default:
                $transactions->orderByDesc('date')->orderByDesc('id');
                break;
        }

        if (isset($filters['per_page'])) {
            return response()->json(
                $transactions->paginate((int) $filters['per_page'])
            );
        }

        return response()->json($transactions->get());
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'description' => ['required', 'string', 'max:255'],
            'category' => ['required', 'string', 'max:100'],
            'amount' => ['required', 'numeric', 'min:0.01'],
            'type' => ['required', 'in:income,expense'],
            'date' => ['required', 'date'],
        ]);

        $transaction = $request->user()->transactions()->create($validated);

        return response()->json($transaction, 201);
    }

    public function show(Request $request, Transaction $transaction): JsonResponse
    {
        return response()->json(
            $request->user()->transactions()->findOrFail($transaction->id)
        );
    }

    public function update(Request $request, Transaction $transaction): JsonResponse
    {
        $validated = $request->validate([
            'description' => ['sometimes', 'required', 'string', 'max:255'],
            'category' => ['sometimes', 'required', 'string', 'max:100'],
            'amount' => ['sometimes', 'required', 'numeric', 'min:0.01'],
            'type' => ['sometimes', 'required', 'in:income,expense'],
            'date' => ['sometimes', 'required', 'date'],
        ]);

        $ownedTransaction = $request->user()->transactions()->findOrFail($transaction->id);
        $ownedTransaction->update($validated);

        return response()->json($ownedTransaction->fresh());
    }

    public function destroy(Request $request, Transaction $transaction): JsonResponse
    {
        $request->user()->transactions()->findOrFail($transaction->id)->delete();

        return response()->json(null, 204);
    }
}
