<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Budget;
use App\Models\Transaction;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class CategoryController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        return response()->json(
            $request->user()->categories()->orderBy('name')->get()
        );
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => [
                'required',
                'string',
                'max:100',
                Rule::unique('categories', 'name')->where('user_id', $request->user()->id),
            ],
        ]);

        $category = $request->user()->categories()->create($validated);

        return response()->json($category, 201);
    }

    public function show(Request $request, Category $category): JsonResponse
    {
        return response()->json(
            $request->user()->categories()->findOrFail($category->id)
        );
    }

    public function update(Request $request, Category $category): JsonResponse
    {
        $category = $request->user()->categories()->findOrFail($category->id);
        $validated = $request->validate([
            'name' => [
                'sometimes',
                'required',
                'string',
                'max:100',
                Rule::unique('categories', 'name')
                    ->where('user_id', $request->user()->id)
                    ->ignore($category->id),
            ],
        ]);

        $oldName = $category->name;

        $userId = $request->user()->id;

        DB::transaction(function () use ($category, $validated, $oldName, $userId) {
            $category->update($validated);

            Transaction::query()
                ->where('category', $oldName)
                ->where('user_id', $userId)
                ->update(['category' => $category->name]);

            Budget::query()
                ->where('category', $oldName)
                ->where('user_id', $userId)
                ->update(['category' => $category->name]);
        });

        return response()->json($category->fresh());
    }

    public function destroy(Request $request, Category $category): JsonResponse
    {
        $category = $request->user()->categories()->findOrFail($category->id);
        $userId = $request->user()->id;
        $replacementName = $request->user()->categories()
            ->where('id', '!=', $category->id)
            ->orderBy('name')
            ->value('name') ?? 'Other';

        DB::transaction(function () use ($category, $replacementName, $userId) {
            Transaction::query()
                ->where('category', $category->name)
                ->where('user_id', $userId)
                ->update(['category' => $replacementName]);

            Budget::query()
                ->where('category', $category->name)
                ->where('user_id', $userId)
                ->delete();

            $category->delete();
        });

        return response()->json(null, 204);
    }
}
