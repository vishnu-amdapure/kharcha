<?php

namespace Tests\Feature;

use App\Models\Transaction;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class TransactionApiTest extends TestCase
{
    use RefreshDatabase;

    public function test_transaction_api_requires_authentication(): void
    {
        $this->getJson('/api/transactions')
            ->assertUnauthorized()
            ->assertJsonPath('message', 'Unauthenticated.');
    }

    public function test_user_can_filter_and_paginate_only_their_transactions(): void
    {
        $user = User::factory()->create();
        $anotherUser = User::factory()->create();

        Transaction::create([
            'user_id' => $user->id,
            'description' => 'Lunch with team',
            'category' => 'Food',
            'amount' => 250,
            'type' => 'expense',
            'date' => '2026-10-06',
        ]);

        Transaction::create([
            'user_id' => $user->id,
            'description' => 'Bus fare',
            'category' => 'Travel',
            'amount' => 80,
            'type' => 'expense',
            'date' => '2026-10-07',
        ]);

        Transaction::create([
            'user_id' => $anotherUser->id,
            'description' => 'Lunch from another account',
            'category' => 'Food',
            'amount' => 500,
            'type' => 'expense',
            'date' => '2026-10-06',
        ]);

        Sanctum::actingAs($user);

        $this->getJson('/api/transactions?type=expense&category=Food&search=Lunch&from=2026-10-01&to=2026-10-31&per_page=1&page=1')
            ->assertOk()
            ->assertJsonPath('total', 1)
            ->assertJsonPath('current_page', 1)
            ->assertJsonPath('per_page', 1)
            ->assertJsonPath('data.0.description', 'Lunch with team')
            ->assertJsonPath('data.0.user_id', $user->id);
    }

    public function test_invalid_transaction_type_filter_returns_validation_error(): void
    {
        Sanctum::actingAs(User::factory()->create());

        $this->getJson('/api/transactions?type=wrong')
            ->assertUnprocessable()
            ->assertJsonValidationErrors('type');
    }
}
