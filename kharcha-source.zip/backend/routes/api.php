<?php

use App\Http\Controllers\CategoryController;
use App\Http\Controllers\BudgetController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DataBackupController;
use App\Http\Controllers\DashboardSummaryController;
use App\Http\Controllers\MonthlyReportController;
use App\Http\Controllers\TransactionController;
use App\Http\Controllers\RecurringTransactionController;
use App\Http\Controllers\UdharController;
use Illuminate\Support\Facades\Route;

Route::post('auth/register', [AuthController::class, 'register'])
    ->middleware('throttle:5,1');
Route::post('auth/login', [AuthController::class, 'login'])
    ->middleware('throttle:5,1');
Route::post('auth/forgot-password', [AuthController::class, 'forgotPassword'])
    ->middleware('throttle:5,1');
Route::post('auth/reset-password', [AuthController::class, 'resetPassword'])
    ->middleware('throttle:5,1');

Route::middleware('auth:sanctum')->group(function () {
    Route::post('auth/logout', [AuthController::class, 'logout']);
    Route::get('backup', [DataBackupController::class, 'show']);
    Route::post('backup/restore', [DataBackupController::class, 'restore'])
        ->middleware('throttle:3,1');
    Route::put('profile', [AuthController::class, 'updateProfile']);
    Route::post('profile/photo', [AuthController::class, 'updateProfilePhoto']);
    Route::delete('profile/photo', [AuthController::class, 'deleteProfilePhoto']);
    Route::patch('profile/password', [AuthController::class, 'updatePassword'])
        ->middleware('throttle:5,1');
    Route::apiResource('transactions', TransactionController::class);
    Route::post('recurring-transactions/process-due', [RecurringTransactionController::class, 'processDue']);
    Route::apiResource('recurring-transactions', RecurringTransactionController::class)
        ->only(['index', 'store', 'update', 'destroy']);
    Route::apiResource('categories', CategoryController::class);
    Route::apiResource('budgets', BudgetController::class);
    Route::get('dashboard/summary', [DashboardSummaryController::class, 'show']);
    Route::get('reports/monthly', [MonthlyReportController::class, 'show']);
    Route::apiResource('udhars', UdharController::class);
    Route::post('udhars/{udhar}/payments', [UdharController::class, 'storePayment']);
});
