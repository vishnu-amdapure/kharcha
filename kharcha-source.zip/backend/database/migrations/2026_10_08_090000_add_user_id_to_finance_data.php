<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('transactions', function (Blueprint $table) {
            $table->foreignId('user_id')->nullable()->after('id')->constrained()->nullOnDelete();
            $table->index(['user_id', 'date']);
        });

        Schema::table('categories', function (Blueprint $table) {
            $table->foreignId('user_id')->nullable()->after('id')->constrained()->nullOnDelete();
            $table->dropUnique('categories_name_unique');
            $table->unique(['user_id', 'name'], 'categories_user_name_unique');
        });

        Schema::table('budgets', function (Blueprint $table) {
            $table->foreignId('user_id')->nullable()->after('id')->constrained()->nullOnDelete();
            $table->dropUnique('budgets_category_month_unique');
            $table->unique(['user_id', 'category', 'month'], 'budgets_user_category_month_unique');
        });

        Schema::table('udhars', function (Blueprint $table) {
            $table->foreignId('user_id')->nullable()->after('id')->constrained()->nullOnDelete();
            $table->index(['user_id', 'date']);
        });
    }

    public function down(): void
    {
        Schema::table('udhars', function (Blueprint $table) {
            $table->dropIndex(['user_id', 'date']);
            $table->dropConstrainedForeignId('user_id');
        });

        Schema::table('budgets', function (Blueprint $table) {
            $table->dropUnique('budgets_user_category_month_unique');
            $table->dropConstrainedForeignId('user_id');
            $table->unique(['category', 'month'], 'budgets_category_month_unique');
        });

        Schema::table('categories', function (Blueprint $table) {
            $table->dropUnique('categories_user_name_unique');
            $table->dropConstrainedForeignId('user_id');
            $table->unique('name', 'categories_name_unique');
        });

        Schema::table('transactions', function (Blueprint $table) {
            $table->dropIndex(['user_id', 'date']);
            $table->dropConstrainedForeignId('user_id');
        });
    }
};
