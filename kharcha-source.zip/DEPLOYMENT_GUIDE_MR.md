# Kharcha website publish guide

Kharcha chi public website ani app ekach Render service var deploy hotat:

- `/` — Google sathi public Kharcha homepage.
- `/app/` — account create/login karun app vapraychi jaga.
- `/api/` — Laravel API.

## Free demo sathi laganare accounts

1. GitHub madhye `vishnu-amdapure/kharcha` navacha private repo aahe. Project upload kelyavar tyalach Render madhye connect kara.
2. Render madhye free Docker Web Service tayar kara. `render.yaml` ani `Dockerfile` tayari aahet.
3. Supabase madhye free PostgreSQL project tayar kara; database connection details Render madhye secrets mhanun taka.

Supabase project tayar kartana database password swatah theva. Password, `APP_KEY`, `.env` kiwa database file GitHub var commit karu naka.

## Render secrets

Render service tayar zalyavar Settings/Environment madhye `render.yaml` madhil `sync: false` items bharayche:

- `APP_KEY` — local PHP madhun key generate kara: `php -r "echo 'base64:' . base64_encode(random_bytes(32));"` . To key fakt Render secret field madhye taka; chat kiwa GitHub madhye nahi.
- `APP_URL` — Render ne dilela app cha `https://...onrender.com` URL.
- `FRONTEND_URL` — hech Render URL.
- `DB_HOST`, `DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD` — Supabase madhil connection settings.

`DB_PORT` 5432 ani `DB_SSLMODE` `require` asach theva, jo paryant Supabase ne vegli connection paddhat dileli nasel. Render deploy suru zalyavar container `php artisan migrate --force` swatah chalavto.

## Free plan che maryaditpan

- Render cha free web service 15 minute request nasel tar spin down hoto; pudhcha request sadharan ek minute gheu shakto. Render free service la persistent disk nahi.
- Supabase Free project kami database activity asel tar 7 divasanni pause hou shakto; free database quota 500 MB aahe.
- Free setup la backup, uptime kiwa 24/7 availability chi khatri nahi. He demo ani shiknyasathi aahe; lokanni mahatvache khare financial records vaparnyapurvi reliable hosting, database backups, privacy policy, account-data deletion ani email service lavne garjeche aahe.
- `MAIL_MAILER=log` mule account/password-reset email baher pathavle jat nahit. Password reset vapraycha asel tar production email provider configure kara.
- Google Search madhye site lagech disel yachi khatri naste. Site public deploy zalyavar Google Search Console madhye site verify karun sitemap/indexing request dyavi lagte.

## Deploy zalyavar

1. Render dila URL browser madhye ughadun homepage paha.
2. `https://<render-host>/app/` ughadun nava test account tayar kara.
3. Test account madhyech transaction, budget, lending, recurring entry, report ani backup check kara.
4. Homepage `robots.txt`, title/description ani author credit check kara. Google Search Console madhye URL-prefix property add karun ownership verify kara; Google ne index karayla kahi vel lagu shakto.

Local database/khare records cloud demo database madhye copy karu naka.
