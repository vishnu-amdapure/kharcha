# Kharcha: React + Laravel API सुरू करण्याची step-by-step guide

या guide मध्ये आधी React चालवायचा, नंतर Laravel project तयार करून पहिला पूर्ण Transactions CRUD API जोडायचा आहे. सध्या mock data बंद आहे. Laravel server चालू नसेल तर React dashboard वर connection error दिसेल.

## आधी हे लक्षात घ्या

या computer वर Node.js आणि Composer सापडले. पण `php` command सध्या उपलब्ध नाही. त्यामुळे Laravel सुरू करण्याआधी PHP install कर आणि नवीन PowerShell terminal उघड. Windows वर Laravel Herd हा PHP/Composer साठी सोपा पर्याय आहे. Laravel 13 ला PHP 8.3 किंवा त्यापुढची आवृत्ती लागते. [Laravel installation guide](https://laravel.com/docs/13.x/installation) पाहा.

Install झाल्यावर PowerShell मध्ये हे चालव:

```powershell
php -v
composer -V
```

दोन्ही version दिसले की पुढे जा.

## 1. React frontend चालव

1. VS Code उघड.
2. **File → Open Folder** निवडून हा folder उघड:

   ```text
   C:\Users\admin\Documents\Codex\2026-10-06\mal\outputs\expense-tracker
   ```

3. **Terminal → New Terminal** निवड.
4. Terminal मध्ये हे commands एकेक करून चालव:

   ```powershell
   cd frontend
   npm install --cache .npm-cache
   npm run dev
   ```

5. Terminal मध्ये Vite जी URL दाखवेल (साधारण `http://localhost:5173/`) ती browser मध्ये उघड. Homepage दिसेल; finance app साठी URL च्या शेवटी `/app/` लाव (उदा. `http://localhost:5173/app/`). हा terminal चालूच ठेव.

## 2. Laravel backend project तयार कर

VS Code मध्ये अजून एक terminal उघड (**Terminal → New Terminal**). हा terminal frontend terminal पासून वेगळा ठेव.

```powershell
cd "C:\Users\admin\Documents\Codex\2026-10-06\mal\outputs\expense-tracker"
composer create-project laravel/laravel backend
cd backend
php artisan install:api
```

`install:api` मुळे `routes/api.php` तयार होतो. Laravel API routes मध्ये `/api` prefix आपोआप लागतो, त्यामुळे route मध्ये `api/` लिहू नको. [Laravel API routes docs](https://laravel.com/docs/13.x/routing#api-routes).

## 3. Transaction model, migration, controller scaffold तयार कर

Laravel terminal (`backend` folder) मध्ये:

```powershell
php artisan make:model Transaction -mcr
```

आता VS Code Explorer मध्ये `backend/database/migrations` उघड. नुकतीच तयार झालेली `*_create_transactions_table.php` file उघड आणि पूर्ण contents खालील code ने replace कर:

```php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->id();
            $table->string('description');
            $table->string('category')->default('Other');
            $table->decimal('amount', 12, 2);
            $table->string('type');
            $table->date('date');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('transactions');
    }
};
```

हे fields आपल्या React form बरोबर जुळतात: description, category, amount, type आणि date.

## 4. Eloquent model भरा

`backend/app/Models/Transaction.php` उघड. पूर्ण file खालीलप्रमाणे ठेवा:

```php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    protected $fillable = [
        'description',
        'category',
        'amount',
        'type',
        'date',
    ];

    protected function casts(): array
    {
        return [
            'amount' => 'decimal:2',
            'date' => 'date:Y-m-d',
        ];
    }
}
```

## 5. Controller मध्ये CRUD code टाक

`backend/app/Http/Controllers/TransactionController.php` उघड. पूर्ण file खालील code ने replace कर:

```php
<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class TransactionController extends Controller
{
    public function index(): JsonResponse
    {
        return response()->json(
            Transaction::query()->orderByDesc('date')->orderByDesc('id')->get()
        );
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'description' => ['required', 'string', 'max:255'],
            'category' => ['required', 'string', 'max:100'],
            'amount' => ['required', 'numeric', 'min:0.01'],
            'type' => ['required', 'in:income,expense'],
            'date' => ['required', 'date'],
        ]);

        $transaction = Transaction::create($validated);

        return response()->json($transaction, 201);
    }

    public function show(Transaction $transaction): JsonResponse
    {
        return response()->json($transaction);
    }

    public function update(Request $request, Transaction $transaction): JsonResponse
    {
        $validated = $request->validate([
            'description' => ['sometimes', 'required', 'string', 'max:255'],
            'category' => ['sometimes', 'required', 'string', 'max:100'],
            'amount' => ['sometimes', 'required', 'numeric', 'min:0.01'],
            'type' => ['sometimes', 'required', 'in:income,expense'],
            'date' => ['sometimes', 'required', 'date'],
        ]);

        $transaction->update($validated);

        return response()->json($transaction->fresh());
    }

    public function destroy(Transaction $transaction): JsonResponse
    {
        $transaction->delete();

        return response()->json(null, 204);
    }
}
```

## 6. API routes लिही

`backend/routes/api.php` उघडून खालील contents ठेवा:

```php
<?php

use App\Http\Controllers\TransactionController;
use Illuminate\Support\Facades\Route;

Route::apiResource('transactions', TransactionController::class);
```

यातून हे endpoints मिळतील:

| Method | URL | काम |
| --- | --- | --- |
| GET | `/api/transactions` | व्यवहारांची यादी |
| POST | `/api/transactions` | नवीन व्यवहार |
| GET | `/api/transactions/{id}` | एक व्यवहार |
| PUT/PATCH | `/api/transactions/{id}` | व्यवहार बदलणे |
| DELETE | `/api/transactions/{id}` | व्यवहार delete करणे |

## 7. SQLite database तयार करून migrations चालव

नवीन Laravel project मध्ये `.env` उघडून database setting SQLite आहे याची खात्री कर. साधारणपणे:

```env
DB_CONNECTION=sqlite
```

`backend/database/database.sqlite` file नसेल तर PowerShell मध्ये backend folder मधून तयार कर:

```powershell
New-Item database/database.sqlite -ItemType File
```

आता migrations चालव:

```powershell
php artisan migrate
php artisan route:list --path=api/transactions
```

Route list मध्ये transaction routes दिसले की backend सुरू कर:

```powershell
php artisan serve --host=127.0.0.1 --port=8000
```

हा terminal देखील चालूच ठेव. API address `http://127.0.0.1:8000/api/transactions` आहे.

## 8. React ला Laravel URL सांग

`frontend` folder मध्ये (जिथे `package.json` आहे) `.env.example` ची copy करून `.env` नाव दे. `.env` मध्ये:

```env
VITE_API_URL=http://127.0.0.1:8000/api
```

Vite terminal मध्ये `Ctrl+C` दाबून बंद कर, मग पुन्हा सुरू कर:

```powershell
npm run dev
```

Browser refresh कर. API नीट सुरू असेल तर orange connection error नाहीसा होईल आणि आधी व्यवहार नसल्याने empty state दिसेल.

## 9. Frontend मधून पहिला व्यवहार save करून पाहा

Dashboard वरील **Add transaction** दाब. Description, amount, date आणि category भरून **Save transaction** कर. React चे `src/api.js` form fields API साठी `description`, `category`, `amount`, `type`, `date` मध्ये रूपांतरित करते. Laravel मध्ये row तयार होईल आणि `GET /api/transactions` मधून परत येईल.

PowerShell मधून API तपासायचा असल्यास तिसरा terminal उघडून:

```powershell
Invoke-RestMethod -Uri "http://127.0.0.1:8000/api/transactions" -Method Get
```

## पुढचे टप्पे

पहिला Transactions API चालल्यावर आपण categories table/API, dashboard summary, update flow, login/register आणि Sanctum token authentication एकेक करून जोडू. API helper bearer token header आधीपासून support करतो; auth routes आणि token flow पुढे जोडायचे आहेत.
